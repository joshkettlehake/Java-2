package cs1181.lab04.kettlehake;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Assignment {

    private Label label;
    private TextField pointsMade;
    private Label slash;
    private TextField pointsPossible;

    // No args constuctor
    public Assignment() {
    }

    // Full constructor
    public Assignment(Label label, TextField pointsMade, Label slash, TextField pointsPossible) {
        this.label = label;
        this.pointsMade = pointsMade;
        this.slash = slash;
        this.pointsPossible = pointsPossible;
    }

    // Getters and setters
    public Label getLabel() {
        return label;
    }

    public void setLabel(Label label) {
        this.label = label;
    }

    public TextField getPointsMade() {
        return pointsMade;
    }

    public void setPointsMade(TextField pointsMade) {
        this.pointsMade = pointsMade;
    }

    public Label getSlash() {
        return slash;
    }

    public void setSlash(Label slash) {
        this.slash = slash;
    }

    public TextField getPointsPossible() {
        return pointsPossible;
    }

    public void setPointsPossible(TextField pointsPossible) {
        this.pointsPossible = pointsPossible;
    } // End getters and setters
} // End Assignment class
