/*
 * I'm actually kind of proud of how smoothly this lab came along.
 * I started from scratch and built my way up. "Started from the bottom, now we're here?"
 * I'm sure it isn't perfect, but I'm happy none the less.
 * This program allows the user to enter the number of assignments they would like to have graded,
 * it allows them to enter the pointsMade and pointsPossible for each assignment,
 * and it calculates the combined grade of those assignments.
 * I also made a little catch, that the program will exit if the user enters a number less than one into the initial TextInputDialog.
 * I wish I knew how to do a ScrollBar in case the user wanted to enter 100 assignments. That would be cool...
 */
package cs1181.lab04.kettlehake;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Optional;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/*
 * Joshua Kettlehae
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
 */
public class CS1181Lab04Kettlehake extends Application {

    private final int INITIAL_WIDTH_IN_PIXELS = 500;
    private final int INITAL_HEIGHT_IN_PIXELS = 400;
    private Scene scene;
    private HBox pane;

    // Necessary
    public static void main(String[] args) {
        launch(args);
    } // End main method

    // The getNumberOfAssignments method creates a TextInputDialog.
    // The number the user enters is then used to create VBoxes in the primaryStage.
    private int getNumberOfAssignments() {
        int numberOfAssignments = Integer.MIN_VALUE;
        boolean isFinished = false;

        while (isFinished == false) {
            // Template from Cheatham's notes
            TextInputDialog getsNumberOfAssignments = new TextInputDialog();
            getsNumberOfAssignments.setTitle("Grade Calculator");
            getsNumberOfAssignments.setContentText("How many assignments do you have? ");
            getsNumberOfAssignments.setResizable(true);

            Optional<String> result = getsNumberOfAssignments.showAndWait();

            if (result.isPresent()) {
                try {
                    numberOfAssignments = Integer.parseInt(result.get());
                    isFinished = true;
                } catch (NumberFormatException e) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("NumberFormatException");
                    alert.setHeaderText(null);
                    alert.setContentText("You must enter an integer.");
                    alert.showAndWait();
                    isFinished = false;
                } // End try-catch
                if (numberOfAssignments <= 0 && numberOfAssignments != Integer.MIN_VALUE) {
                    isFinished = false;
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("NumberFormatException");
                    alert.setHeaderText(null);
                    alert.setContentText("You must enter a positive integer.");
                    alert.showAndWait();
                } // End if statement
            } // End if statement
        } // End while loop
        return numberOfAssignments;
    } // End getNumberOfAssignments method

    // The calculateGrade method uses the assignments ArrayList to .getPointsMade and PointsPossible from the primaryStage.
    // Then, it runs a tally total and some math to calculate the grade.
    // The grading math and the Alert are from the starter code.
    private void calculateGrade(ArrayList<Assignment> assignments) {
        int pointsMade = 0;
        int pointsPossible = 0;

        // Tallies pointsMade and pointsPossible
        for (int i = 0; i < assignments.size(); i++) {

            try {
                pointsMade = (pointsMade + Integer.parseInt(assignments.get(i).getPointsMade().getText()));
                pointsPossible = (pointsPossible + Integer.parseInt(assignments.get(i).getPointsPossible().getText()));
                // isFinished = true; 
            } catch (NumberFormatException e) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("NumberFormatException");
                alert.setHeaderText(null);
                alert.setContentText("You must enter an integer.");
                alert.showAndWait();
                return;
            } // End try-catch // End try-catch
        } // End for loop

        // Calculates grade and round to the nearest tenth
        double grade = pointsMade / (double) pointsPossible;
        grade = Math.round(grade * 1000);
        grade /= 10;

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Grade Calculator");
        alert.setHeaderText(null);
        alert.setContentText("Grade: " + grade);
        alert.showAndWait();
    } // End calculateGrade method

    private void addAssignment(VBox root, Button calculateButton, Button addAssignmentButton, ArrayList<Assignment> assignments) {
        // Removes the buttons to keep assignments in order
        root.getChildren().remove(calculateButton);
        root.getChildren().remove(addAssignmentButton);

        // Creates a new Assignment
        Assignment as = new Assignment();
        as.setLabel(new Label("Assignment " + (assignments.size() + 1)));
        as.setPointsMade(new TextField());
        as.setSlash(new Label("/"));
        as.setPointsPossible(new TextField());
        assignments.add(as);

        // Adds the new Assignment to root
        pane = new HBox(10);
        pane.getChildren().addAll(assignments.get(assignments.size() - 1).getLabel(),
                assignments.get(assignments.size() - 1).getPointsMade(),
                assignments.get(assignments.size() - 1).getSlash(),
                assignments.get(assignments.size() - 1).getPointsPossible());
        root.getChildren().add(pane);

        // Adds buttons back
        root.getChildren().add(calculateButton);
        root.getChildren().add(addAssignmentButton);
    } // End addAssignment method

    @Override
    public void start(Stage primaryStage) {
        // Calls for the TextInputDialog
        int numberOfAssignments = getNumberOfAssignments();
        // The required ArrayList
        ArrayList<Assignment> assignments = new ArrayList<>();
        primaryStage.setTitle("Grade Calculator");

        VBox root = new VBox(10);
        root.setPadding(new Insets(10, 10, 10, 10));
        scene = new Scene(root, INITIAL_WIDTH_IN_PIXELS, INITAL_HEIGHT_IN_PIXELS);
        primaryStage.setScene(scene);
        primaryStage.show();

        // Creates instances of Assignment(s)
        for (int i = 0; i < numberOfAssignments; i++) {
            Assignment as = new Assignment();
            as.setLabel(new Label("Assignment " + (i + 1)));
            as.setPointsMade(new TextField());
            as.setSlash(new Label("/"));
            as.setPointsPossible(new TextField());
            assignments.add(as);
        } // End for loop

        // Adds instances of Assignment(s) to the VBox
        for (int i = 0; i < assignments.size(); i++) {
            pane = new HBox(10);
            pane.getChildren().addAll(assignments.get(i).getLabel(),
                    assignments.get(i).getPointsMade(),
                    assignments.get(i).getSlash(),
                    assignments.get(i).getPointsPossible());
            root.getChildren().add(pane);
        } // End for loop

        // Calls calculateGrade method
        Button calculateButton = new Button("Calculate Grade");
        root.getChildren().add(calculateButton);
        calculateButton.setOnAction(e -> {
            calculateGrade(assignments);
        }); // End calculateButton's setOnAction

        // Calls add Assignment method
        Button addAssignmentButton = new Button("Add Assignment");
        root.getChildren().add(addAssignmentButton);
        addAssignmentButton.setOnAction(e -> {
            addAssignment(root, calculateButton, addAssignmentButton, assignments);
        }); // End addAssignment's setOnAction
    } // End start method
} // End lab03
