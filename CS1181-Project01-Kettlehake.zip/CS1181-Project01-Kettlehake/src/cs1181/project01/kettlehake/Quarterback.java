package cs1181.project01.kettlehake;

import java.io.Serializable;

// implementing Serializable is key!
public class Quarterback implements Serializable{
    private String firstName;
    private String lastName;
    private int touchdownPasses;
    private int interceptions;
    private int passingYards;
    private boolean madePlayoffs;

    // Full args constructor
    public Quarterback(String firstName, String lastName, int touchdownPasses, int interceptions, int passingYards, boolean madePlayoffs) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.touchdownPasses = touchdownPasses;
        this.interceptions = interceptions;
        this.passingYards = passingYards;
        this.madePlayoffs = madePlayoffs;
    }

    // A full complement of getters. No setters needed.
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getTouchdownPasses() {
        return touchdownPasses;
    }

    public int getInterceptions() {
        return interceptions;
    }

    public int getPassingYards() {
        return passingYards;
    }

    public boolean isMadePlayoffs() {
        return madePlayoffs;
    }
    
    @Override
    public String toString() {
        return firstName + " " + lastName + " threw " + touchdownPasses + " touchdown"
                + " passes, " + interceptions + " interceptions, had " + passingYards
                + " passing yards, and made the playoffs is " + madePlayoffs +".";
    } // End toString override
} // End Quarterback class
