/*
 * This program can do some fun things with an ArrayList of Quarterback (objects).
 * It reads and writes the ArrayList from and to a .dat file.
 * It can add and delete new Quarterback(s) from the ArrayList.
 * It can print all of their stats.
 * It can search for and individual Quarterback within the ArrayList.
 * And, it does a pretty good job of quitting. Have fun.
 */
package cs1181.project01.kettlehake;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/*
 * Joshua Kettlehae
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
 */
public class CS1181Project01Kettlehake {

    // The add method allows the user to add a new Quarterback to the ArrayList.
    public static void add(Scanner userInput, ArrayList<Quarterback> quarterbacks) {
        String firstName;
        String lastName;
        int touchdownPasses = Integer.MIN_VALUE;
        int interceptions = Integer.MIN_VALUE;
        int passingYards = Integer.MIN_VALUE;
        boolean madePlayoffs = false;
        boolean isFinished = false;

        // There is no reason to have try-catches on the first and last names.
        System.out.print("What is the quarterbacks first name? --> ");
        firstName = userInput.next();
        System.out.print("What is the quarterbacks last name? --> ");
        lastName = userInput.next();
        // The next four entries have try-catches to prevent the user from entering invalid input.
        // They are promply reprompted if they do.
        while (isFinished == false) {
            System.out.print("How many touchdowns did he throw? --> ");
            try {
                touchdownPasses = userInput.nextInt();
                isFinished = true;
            } catch (InputMismatchException e) {
                System.err.println("You entered an invalid input.");
                userInput.next();
                isFinished = false;
            } // End try-catch
        } // End while loop
        isFinished = false;
        while (isFinished == false) {
            System.out.print("How many interceptions did he throw? --> ");
            try {
                interceptions = userInput.nextInt();
                isFinished = true;
            } catch (InputMismatchException e) {
                System.err.println("You entered an invalid input.");
                userInput.next();
                isFinished = false;
            } // End try-catch
        } // End while loop
        isFinished = false;
        while (isFinished == false) {
            System.out.print("How many passing yards did he have? --> ");
            try {
                passingYards = userInput.nextInt();
                isFinished = true;
            } catch (InputMismatchException e) {
                System.err.println("You entered an invalid input.");
                userInput.next();
                isFinished = false;
            } // End try-catch
        } // End while loop
        isFinished = false;
        while (isFinished == false) {
            System.out.print("Did he make the playoffs (true/false)? --> ");
            try {
                madePlayoffs = userInput.nextBoolean();
                isFinished = true;
            } catch (InputMismatchException e) {
                System.err.println("You entered an invalid input.");
                userInput.next();
                isFinished = false;
            } // End try-catch
        } // End while loop
        // The new Quarterback is made and added to the ArrayList here.
        Quarterback newQB = new Quarterback(firstName, lastName, touchdownPasses, interceptions, passingYards, madePlayoffs);
        quarterbacks.add(newQB);
        // The user is made aware that their Quarterback has successfully been added.
        System.out.println("\n" + firstName + " " + lastName + " has been added to the list.");
    } // End add method

    // The delete method allows the user to delete a Quarterback from the ArrayList.
    public static void delete(Scanner userInput, ArrayList<Quarterback> quarterbacks) {
        String firstName;
        String lastName;
        boolean needsErrorMessage = true;

        // Allowing the user to enter the Quarterbacks first and last name.
        System.out.print("What is the first name of the quarterback you would like to delete? --> ");
        firstName = userInput.next();
        System.out.print("What is the last name of the quarterback you would like to delete? --> ");
        lastName = userInput.next();

        // Iterating through the ArrayList for the userInput first and last name.
        for (int i = 0; i < quarterbacks.size(); i++) {
            if (firstName.equalsIgnoreCase(quarterbacks.get(i).getFirstName())
                    && lastName.equalsIgnoreCase(quarterbacks.get(i).getLastName())) {
                quarterbacks.remove(i);
                // Making the user aware that their Quarterback has been deleted from the ArrayList.
                System.out.println("\n" + firstName + " " + lastName + " has been deleted from the list.");
                i = quarterbacks.size();
                needsErrorMessage = false;
            } // End if
        } // End for loop
        if (needsErrorMessage == true) {
            // Making the user aware that their Quarterback was not found in the ArrayList.
            System.err.println("The quarterback you entered is not in the list.\n");
        } // End if
    }// End delete method

    // The stats method prints to console the number of Quarterbacks currently in the ArrayList and displays them via a toString override.
    public static void stats(ArrayList<Quarterback> quarterbacks) {
        int j = 0;
        for (int i = 0; i < quarterbacks.size(); i++) {
            j = j + 1;
        } // End for loop
        System.out.println("There are " + j + " quarterbacks in the list.\nThey are:");
        for (int i = 0; i < quarterbacks.size(); i++) {
            System.out.println(quarterbacks.get(i));
        } // End for loop
    } // End stats method

    // The search method uses the same ideas as the delete method.
    // It takes the userInput first and last name, and it displays just that Quarterback to the console.
    private static void search(Scanner userInput, ArrayList<Quarterback> quarterbacks) {
        String firstName;
        String lastName;
        boolean needsErrorMessage = true;

        System.out.print("What is the first name of the quarterback you would like to search for? --> ");
        firstName = userInput.next();
        System.out.print("What is the last name of the quarterback you would like to search for? --> ");
        lastName = userInput.next();

        for (int i = 0; i < quarterbacks.size(); i++) {
            if (firstName.equalsIgnoreCase(quarterbacks.get(i).getFirstName())
                    && lastName.equalsIgnoreCase(quarterbacks.get(i).getLastName())) {
                System.out.println("\n" + quarterbacks.get(i));
                needsErrorMessage = false;
            } // End if 
        } // End for loop
        if (needsErrorMessage == true) {
            // Makes the user aware if the userInput first and last name was not found in the ArrayList.
            System.err.println("The quarterback you entered is not in the list.\n");
        } // End if
    } // End search method

    public static void main(String[] args) {
        // Variables list
        Scanner userInput = new Scanner(System.in);
        boolean isRunning = true;
        final String add = "add";
        final String delete = "delete";
        final String stats = "stats";
        final String search = "search";
        final String quit = "quit";
        // If one were to want to load from a different file, they could enter that file (.dat) here.
        final String fileName = "data.dat";

        ArrayList<Quarterback> quarterbacks = new ArrayList<>();

        // Loading the ArrayList from fileName.
        // John talked to me about grouping exceptions and ignored.
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File(fileName)));
            quarterbacks = (ArrayList<Quarterback>) ois.readObject();
            // CLOSE YOUR FILES!
            ois.close();
        } catch (IOException | ClassNotFoundException ignored) {
        } // End try-catch

        System.out.println("This program allows you to veiw and modify NFL\nquart"
                + "erback statistics for the 2019-2020 season.");
        System.out.println("\nWhat would you like to do?");
        System.out.println("You can add another quarterback by entering 'add'");
        System.out.println("You can delete a quarterback by entering 'delete'");
        System.out.println("You can view the complete list by entering 'stats'");
        System.out.println("You can search for an individual quarterback by entering 'search'");
        System.out.println("Enter 'quit' to end the program.");

        // The while loop forces the user to input one of the five Strings I have provided.
        // It will promply reprompt them otherwise...
        while (isRunning == true) {
            System.out.print("\nWhat would you like to do? ---> ");
            String performAction = userInput.next();
            if (performAction.equalsIgnoreCase(add)) {
                add(userInput, quarterbacks);
            } else if (performAction.equalsIgnoreCase(delete)) {
                delete(userInput, quarterbacks);
            } else if (performAction.equalsIgnoreCase(stats)) {
                stats(quarterbacks);
            } else if (performAction.equalsIgnoreCase(search)) {
                search(userInput, quarterbacks);
            } else if (performAction.equalsIgnoreCase(quit)) {
                isRunning = false;
            } else {
                System.err.println("You did not enter an acceptable option.\n");
            } // End if-else if statements
        } // End isRunning while loop

        // Writing the ArrayList to fileName
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File(fileName)));
            oos.writeObject(quarterbacks);
            // CLOSE YOUR FILES!
            oos.close();
        } catch (IOException ignored) {
        } // End try-catch
    } // End main method
} // End of project01
