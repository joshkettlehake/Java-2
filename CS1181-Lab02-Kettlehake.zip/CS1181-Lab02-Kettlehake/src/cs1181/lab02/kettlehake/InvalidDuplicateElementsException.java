package cs1181.lab02.kettlehake;

public class InvalidDuplicateElementsException extends Exception {
    
    public InvalidDuplicateElementsException(){
        super("Your set contains one or more duplicate elements.");
    }
}

