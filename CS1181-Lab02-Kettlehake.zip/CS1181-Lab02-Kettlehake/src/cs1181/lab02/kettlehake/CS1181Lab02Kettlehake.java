/*
 * This class demonstrates the implementation of the CS1181Set class
 */
package cs1181.lab02.kettlehake;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * Joshua Kettlehae
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
 */
public class CS1181Lab02Kettlehake {

    public static void main(String[] args) {
//        // Sample code
//        CS1181Set setA = new CS1181Set(1, 2, 3, 4, 5);
//        System.out.println(setA);
//
//        CS1181Set setB = new CS1181Set(2, 5, 7);
//        System.out.println(setB);
//
//        CS1181Set setC = new CS1181Set(setA);
//        setC.intersection(setB);
//        System.out.println("intersection: " + setC);
//
//        setC = new CS1181Set(setA);
//        setC.union(setB);
//        System.out.println("union: " + setC);
//
//        setC = new CS1181Set(setA);
//        setC.difference(setB);
//        System.out.println("difference: " + setC);

        // Sample code
        CS1181SetLab02 setA = null;
        try {
            setA = new CS1181SetLab02(1, 2, 3, 3, 4, 5);
            System.out.println(setA);
        } catch (InvalidDuplicateElementsException ex) {
            Logger.getLogger(CS1181Lab02Kettlehake.class.getName()).log(Level.SEVERE, null, ex);
        }

        CS1181SetLab02 setB = null;
        try {
            setB = new CS1181SetLab02(2, 5, 7);
            System.out.println(setB);
        } catch (InvalidDuplicateElementsException ex) {
            Logger.getLogger(CS1181Lab02Kettlehake.class.getName()).log(Level.SEVERE, null, ex);
        }

        CS1181SetLab02 setC = new CS1181SetLab02(setA);
        setC.intersection(setB);
        System.out.println("intersection: " + setC);

        setC = new CS1181SetLab02(setA);
        setC.union(setB);
        System.out.println("union: " + setC);

        setC = new CS1181SetLab02(setA);
        setC.difference(setB);
        System.out.println("difference: " + setC);

        String fileName = "numberSets.dat";
        try {
            setA.save(fileName);
            // Show that I can save and load, do some sort of junit test...  
        } catch (IOException ex) {
            Logger.getLogger(CS1181Lab02Kettlehake.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            System.out.println("\nLoading from the .dat file:");
            setA.load(fileName);
        } catch (IOException ex) {
            Logger.getLogger(CS1181Lab02Kettlehake.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CS1181Lab02Kettlehake.class.getName()).log(Level.SEVERE, null, ex);
        }

    } // End main method
} // End lab 01
