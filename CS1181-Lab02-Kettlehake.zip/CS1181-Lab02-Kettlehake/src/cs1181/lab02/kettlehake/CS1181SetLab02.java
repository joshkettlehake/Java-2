package cs1181.lab02.kettlehake;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class CS1181SetLab02 extends CS1181Set implements Serializable {

    // Integer ArrayList constructor (pulls from CS1181Set)
    public CS1181SetLab02(int... elements) throws InvalidDuplicateElementsException {
        for (int i = 0; i < elements.length; i++) {
            this.add(elements[i]);
        } // End for loop
        try {
            for (int i = 0; i < this.size(); i++) {
                for (int j = i + 1; j < this.size(); j++) {
                    if (this.get(i) == this.get(j)) {
                        throw new InvalidDuplicateElementsException();
                    } else {
                        // Do nothing
                    } // End if-else
                } // End j for loop
            } // End i for loop
        } catch (InvalidDuplicateElementsException ignored) {
            System.err.println(ignored);
        } // End try-catch
    } // End CS1181SetLab02 integer constructor
    
    // Clone constructor
    public CS1181SetLab02(CS1181SetLab02 setToCloneArrayList) {
        for (int i = 0; i < setToCloneArrayList.size(); i++) {
            this.add(setToCloneArrayList.get(i));
        }
    } // End CS1181Set clone constructor

    // the save method outputs a CS1181SetLab02 object as binary to a file defined in main.
    void save(String fileName) throws IOException {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File(fileName)));
        oos.writeObject(this);
        oos.close();
    } // End save method

    // the load method inputs a CS1181SetLab02 object in a binary file to the console with ascii characters.
    void load(String fileName) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File(fileName)));
        ArrayList<CS1181SetLab02> newList = (ArrayList<CS1181SetLab02>) ois.readObject();
        System.out.println(newList);
        ois.close(); // Is this necessary?
    } // End load method
}
