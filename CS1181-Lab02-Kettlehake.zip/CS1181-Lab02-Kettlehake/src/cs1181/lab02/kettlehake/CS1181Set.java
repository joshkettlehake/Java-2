package cs1181.lab02.kettlehake;

import java.util.ArrayList;

public class CS1181Set extends ArrayList {

    // Integer ArrayList constructor
    public CS1181Set(int... elements) {
        for (int i = 0; i < elements.length; i++) {
            this.add(elements[i]);
        } // End for loop
    } // End CS1181Set integer constructor

    // Clone constructor
    public CS1181Set(CS1181Set setToCloneArrayList) {
        for (int i = 0; i < setToCloneArrayList.size(); i++) {
            this.add(setToCloneArrayList.get(i));
        }
    } // End CS1181Set clone constructor

    // The intersection method retains only integers found in both this. and setZ
    void intersection(CS1181Set setZ) {
        this.retainAll(setZ);
    } // End intersection method

    // The union method causes this. to combine with setZ, then removes all duplicates
    void union(CS1181Set setZ) {
        this.addAll(setZ);
        for (int i = 0; i < this.size(); i++) {
            for (int j = i + 1; j < this.size(); j++) {
                if (this.get(i) == this.get(j)) {
                    this.remove(j);
                } else {
                    // Do nothing
                } // End if-else
            } // End j for loop
        } // End i for loop
    } // End union method

    // The difference method causes this. to retain all integers not found in setZ
    void difference(CS1181Set setZ) {
        this.removeAll(setZ);
    } // End difference method
} // End CS1181Set class
