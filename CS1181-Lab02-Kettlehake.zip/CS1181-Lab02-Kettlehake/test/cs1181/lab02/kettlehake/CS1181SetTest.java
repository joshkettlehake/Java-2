/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs1181.lab02.kettlehake;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author student
 */
public class CS1181SetTest {

    public CS1181SetTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of intersection method, of class CS1181Set.
     */
    @Test
    public void testIntersection() {
        System.out.println("intersection");
        CS1181Set setZ = new CS1181Set(1, 2, 3, 4);
        CS1181Set instance = new CS1181Set(1, 2);
        instance.intersection(new CS1181Set(1, 2));

    }
//
//    /**
//     * Test of union method, of class CS1181Set.
//     */
//    @Test
//    public void testUnion() {
//        System.out.println("union");
//        CS1181Set setZ = null;
//        CS1181Set instance = null;
//        instance.union(setZ);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of difference method, of class CS1181Set.
//     */
//    @Test
//    public void testDifference() {
//        System.out.println("difference");
//        CS1181Set setZ = null;
//        CS1181Set instance = null;
//        instance.difference(setZ);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }

}
