/*
 * This program was to help us to test the time complexities of different fragments of code.
 * I did so while also testing to see how many iterations each fragment was being ut through with respect it long N.
 */
package cs1181.lab09.kettlehake;

public class CS1181Lab09Kettlehake {

    /*
 * Joshua Kettlehae
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
     */
    public static void main(String[] args) {
        long N;
        long i;
        long j;
        long sum;

//         Enter N manually, hard core its value, use a loop, or initialize it
//         in whatever other way you deem most appopriate.
        N = 0;

        System.out.println("Results for N = " + N);

        // fragement #1
        long startTime = System.currentTimeMillis();
        for (i = 1, sum = 0; i <= N; i++) {
            sum++;
        }
        long endTime = System.currentTimeMillis();
        System.out.println("Time 1: " + (endTime - startTime) + "\nsum = " + sum);

        // fragement #2
        startTime = System.currentTimeMillis();
        for (i = 1, sum = 0; i <= 2 * N; i++) {
            sum++;
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time 2: " + (endTime - startTime) + "\nsum = " + sum);

        //fragment #3
        startTime = System.currentTimeMillis();
        for (i = 1, sum = 0; i <= N * N; i++) {
            sum++;
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time 3: " + (endTime - startTime) + "\nsum = " + sum);

        // fragment #4
        startTime = System.currentTimeMillis();
        for (i = 1, sum = 0; i <= N; i++) {
            for (j = 1; j <= N; j++) {
                sum++;
            }
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time 4: " + (endTime - startTime) + "\nsum = " + sum);

        // fragment #5
        startTime = System.currentTimeMillis();
        for (i = 1, sum = 0; i <= N; i++) {
            for (j = 1; j <= N * N; j++) {
                sum++;
            }
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time 5: " + (endTime - startTime) + "\nsum = " + sum);

        // fragment #6
        startTime = System.currentTimeMillis();
        for (i = 1, sum = 0; i <= N; i++) {
            for (j = 1; j <= i; j++) {
                sum++;
            }
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time 6: " + (endTime - startTime) + "\nsum = " + sum);

        // fragment #7
        startTime = System.currentTimeMillis();
        for (i = 1, sum = 0; i <= Math.pow(2, N); i++) {
            sum++;
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time 7: " + (endTime - startTime) + "\nsum = " + sum);

        // fragment #8
        i = N;
        sum = 0;
        startTime = System.currentTimeMillis();
        while (i >= 1) {
            sum++;
            i /= 2;
        }
        endTime = System.currentTimeMillis();
        System.out.println("Time 8: " + (endTime - startTime) + "\nsum = " + sum);
    }
}
