package cs1181.lab05.kettlehake;

/*
 * Joshua Kettlehae
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
 */
public class CS1181Lab05Kettlehake {

    public static void main(String[] args) {

        // Part 01
        Number[] numberArray = new Number[4];
        Number a = 1;
        Number b = 3;
        Number c = 5;
        Number d = -7;
        numberArray[0] = a;
        numberArray[1] = b;
        numberArray[2] = c;
        numberArray[3] = d;
        System.out.println("...PART 01...");
        System.out.println("The maximum value in the numberArray is: " + findMaxLab05Step01(numberArray));

        // Part 02
        String[] animalNames = new String[3];
        String aa = "Lion";
        String bb = "Tiger";
        String cc = "Bear";
        animalNames[0] = aa;
        animalNames[1] = bb;
        animalNames[2] = cc;

        System.out.println("...PART 02...");
        findMaxLab05Step02(numberArray);
        findMaxLab05Step02(animalNames);

        // Part 03
        Sequence<String> s1 = new Sequence(10);
        s1.add("a");
        s1.add("c");
        s1.add("b");
        s1.add("s");
        s1.add("a");
        s1.add("c");
        s1.add("b");

        String item = s1.get(3);
        Sequence<String> s2 = s1.getSequence(4, 3);
        Sequence<String> s3 = s1.getSequence(0, 3);
        Sequence<String> s4 = s1.getSequence(1, 3);
        System.out.println(s2.equals(s3));
        System.out.println(s1.equals(s2));

    }

    // This methed finds the maxNumber in an array of Number(s).
    private static Number findMaxLab05Step01(Number[] numberArray) {
        Number maxNumber = Double.MIN_VALUE;
        if (numberArray.length > 0) {
            for (int i = 0; i < numberArray.length; i++) {
                if (maxNumber.doubleValue() < numberArray[i].doubleValue()) {
                    maxNumber = numberArray[i].doubleValue();
                } else {
                    // Do nothing
                } // End if-else statement
            } // End for loop
        } else {
            System.exit(0);
            System.err.println("numberArray is empty.");
        } // End if-else statement
        return maxNumber;
    } // End findMaxLab05Step01 method

    // This method finds the max in any comparable data type.
    public static <E> void findMaxLab05Step02(E[] arr) {
//        arr = (E[]) new Object();     Cheathem said this was neccessary, but I can't figure out why...
        int currentHigh = 0;
        int charCounter = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].toString().charAt(charCounter) > arr[currentHigh].toString().charAt(charCounter)) {
                currentHigh = i;
            } // End if statement
        } // End for loop
        System.out.println(arr[currentHigh]);
    } // End findMaxLab05Step02 method
} // End Lab05
