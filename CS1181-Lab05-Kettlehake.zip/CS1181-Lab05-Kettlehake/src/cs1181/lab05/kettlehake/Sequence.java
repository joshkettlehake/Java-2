package cs1181.lab05.kettlehake;

public class Sequence<E extends Comparable<E>> {

    private int capacity;

    public Sequence(int capacity) {
        this.capacity = capacity;
    }

    public void add(E item) {

    }

    public E get(int pos) {

        return;
    }

    public Sequence getSequence(int pos, int len) {

        return;
    }

    public int getCount() {

        return;
    }

    public int getCapacity() {
        return capacity;
    }
    
    public boolean equals (Sequence seq){
        boolean isEqual = false;
        return isEqual;
    }
    
    public E findMax(){
        return;
    }
    
    public void print(){
        for (int i = 0; i < this.getCapacity(); i++) {
            System.out.println(this.get(i) + " / ");
        }
    }
}
