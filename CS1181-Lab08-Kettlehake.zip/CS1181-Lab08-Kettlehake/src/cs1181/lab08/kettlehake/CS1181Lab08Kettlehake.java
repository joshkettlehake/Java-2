/*
 * This program is an introduction to recursion
*/

package cs1181.lab08.kettlehake;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CS1181Lab08Kettlehake {
    
 /*
 * Joshua Kettlehae
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
 */
    public static void main(String[] args) throws FileNotFoundException {
//        // Example
//        int[] test = new int[3];
//        test[0] = 2;
//        test[1] = 4;
//        test[2] = 8;
//        System.out.println(groupSum(0, test, 10));
//        System.out.println(groupSum(0, test, 14));
//        System.out.println(groupSum(0, test, 9));
//        // End example

        System.out.println("---Part One---");
        Scanner userInput = new Scanner(System.in);
        System.out.print("Enter a word: ");
        String string = userInput.next();
        recursiveAnagram("", string);

        System.out.println("---Part Two---");
        File file = new File("CS1181-Lab08Data.txt");
        Scanner readFile = new Scanner(file);
        // Reads in the number of testCases
        int testCases = readFile.nextInt();

        // Creating my 2D array
        for (int i = 0; i < testCases; i++) {
            // reading in the numberOfRows
            int numberOfRows = readFile.nextInt();
            int[][] triangle = new int[numberOfRows][numberOfRows];
            for (int j = 0; j < numberOfRows; j++) {
                for (int k = 0; k < numberOfRows; k++) {
                    // reading in the triangles from the .txt file
                    triangle[j][k] = readFile.nextInt();
                } // End k for loop
            } // End j for loop
            int maxSum = 0;
            int column = 0;
            int row = 0;
            // Calling the recursive method
            maxSum(triangle, maxSum, column, row);
        } // End i for loop
    } // End main method

//    public static boolean groupSum(int start, int[] nums, int target){
//        if (start >= nums.length){ // an array with no items
//            return target == 0;
//        } else {
//            // Consider whether "either" option works.
//            // Option 1: we include nums [start] in the sum
//            // Option 2: we do not include nums [start] in the sum
//            return groupSum(start + 1, nums, target - nums[start]) ||
//                    groupSum(start + 1, nums, target); 
//        }
//    }
    // This methed finds all of the permutations of String string.
    private static void recursiveAnagram(String empty, String string) {
        // Our base case. Prints if string.length() having been recursed == 0
        if (string.isEmpty()) {
            System.out.println(empty + string);
        } else {
            // Our recursive step. 
            // It adds what will be our leading character to empty and removes it from string,
            // then it adds to that the permutations of the remaining characters of string.
            for (int i = 0; i < string.length(); i++) {
                recursiveAnagram(empty + string.charAt(i),
                        string.substring(0, i) + string.substring(i + 1, string.length()));
            } // End for loop
        } // End recursive step
    } // End recursiveAnagram method

    // This method works its way through an integer triangle in a limited way to find the maxSum.
    private static void maxSum(int[][] triangle, int maxSum, int column, int row) {
        try {
            // Base case
            if (triangle.length <= row) {
                System.out.println("maxSum: " + maxSum);
            } else {
                // Recursive step.
                // First checks to see which of the two available ints is greater.
                // Then, add the greater of the two to maxSum and moves down the triangle.
                if (triangle[row][column] > triangle[row][column + 1]) {
                    maxSum = maxSum + triangle[row][column];
                    // recursion
                    maxSum(triangle, maxSum, column, (row + 1));
                } else {
                    maxSum = maxSum + triangle[row][column + 1];
                    // recursion
                    maxSum(triangle, maxSum, (column + 1), (row + 1));
                } // End if-else
            } // End recursion step
        } catch (ArrayIndexOutOfBoundsException e) {
        } // End try-catch
    } // End maxSum method
} // End Lab08
