package cs1181.project04.kettlehake;

import java.util.LinkedList;

public abstract class CheckoutLane extends LinkedList<Customer> {
    
    // An abstract class must have abstrace methods...
    public abstract double getCheckoutTime();
    public abstract double getWaitTime();   
}
