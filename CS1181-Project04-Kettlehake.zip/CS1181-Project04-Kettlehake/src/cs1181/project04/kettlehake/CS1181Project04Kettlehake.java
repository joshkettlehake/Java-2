/*
 * This program is a simulation of a supermarket.
 * It can help to calculate which combination of 12 lanes of two 
 * types will be the most efficient for the store. Enjoy.
 */
package cs1181.project04.kettlehake;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;

/*
 * Joshua Kettlehae
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
 */
public class CS1181Project04Kettlehake {

    private static PriorityQueue<Event> eventPQ = new PriorityQueue<>();
    private static ArrayList<CheckoutLane> lanes = new ArrayList<>();
    private static int customerCount;
    private static double totalTimeWaited;

    public static void main(String[] args) {

        // Creating lanes and adding them to my ArrayList
        makeLanes();
        // Reading in the data file
        // If you would like to change the file being read, do it here...
        File file = new File("arrival.txt");
        readInTheFile(file);

        // Runs until the PQ is empty
        while (!eventPQ.isEmpty()) {

            // Polls the nextEvent from the PQ
            Event nextEvent = eventPQ.poll();

            // Handles an ArrivalEvent
            if (nextEvent instanceof ArrivalEvent) {
                eventPQ.offer(makeFinishedShoppingEvent(nextEvent));
                // Handles a FinishedShoppingEvent
            } else if (nextEvent instanceof FinishedShoppingEvent) {
                eventPQ.offer(makeCheckoutEvent(nextEvent));
            } else { // Handles a CheckoutEvent
                checkoutEvent(nextEvent);
            }
        }
        ending();
    } // End main method

    // This method makes our lanes.
    // I left it set at the most efficient setting.
    private static void makeLanes() {
        ExpressCheckoutLane lane1 = new ExpressCheckoutLane();
        ExpressCheckoutLane lane2 = new ExpressCheckoutLane();
        ExpressCheckoutLane lane3 = new ExpressCheckoutLane();
//        ExpressCheckoutLane lane4 = new ExpressCheckoutLane();
//        ExpressCheckoutLane lane5 = new ExpressCheckoutLane();
//        RegularCheckoutLane lane1 = new RegularCheckoutLane();
//        RegularCheckoutLane lane2 = new RegularCheckoutLane();
//        RegularCheckoutLane lane3 = new RegularCheckoutLane();
        RegularCheckoutLane lane4 = new RegularCheckoutLane();
        RegularCheckoutLane lane5 = new RegularCheckoutLane();
        RegularCheckoutLane lane6 = new RegularCheckoutLane();
        RegularCheckoutLane lane7 = new RegularCheckoutLane();
        RegularCheckoutLane lane8 = new RegularCheckoutLane();
        RegularCheckoutLane lane9 = new RegularCheckoutLane();
        RegularCheckoutLane lane10 = new RegularCheckoutLane();
        RegularCheckoutLane lane11 = new RegularCheckoutLane();
        RegularCheckoutLane lane12 = new RegularCheckoutLane();
        lanes.add(lane1);
        lanes.add(lane2);
        lanes.add(lane3);
        lanes.add(lane4);
        lanes.add(lane5);
        lanes.add(lane6);
        lanes.add(lane7);
        lanes.add(lane8);
        lanes.add(lane9);
        lanes.add(lane10);
        lanes.add(lane11);
        lanes.add(lane12);
    } // End makeLanes method

    // This method reads in the file indicated just prior to its method call.
    private static void readInTheFile(File file) {
        double arrivalTime;
        double timePerItem;
        int orderSize;
        try {
            Scanner readFile = new Scanner(file);
            while (readFile.hasNext()) {
                customerCount++;
                arrivalTime = readFile.nextDouble();
                orderSize = readFile.nextInt();
                timePerItem = readFile.nextDouble();
                // Creates a new Customer object
                Customer nc = new Customer();
                nc.setInputNumber(customerCount);
                nc.setOrderSize(orderSize);
                nc.setTimePerItem(timePerItem);
                // Makes an ArrivalEvent and adds it to the PQ
                ArrivalEvent ae = new ArrivalEvent(arrivalTime, nc);
                eventPQ.add(ae);
            }
        } catch (FileNotFoundException e) {
            System.out.println("The file was not found.");
            System.exit(0);
        }
    } // End readInTheFile method

    // This method rounds doubles to the nearest two decimal places.
    public static double round(double d) {
        return Math.round(d * 100.0) / 100.0;
    } // End round method

    // This method takes ArrivalEvents and makes them FinishedShoppingEvents
    public static FinishedShoppingEvent makeFinishedShoppingEvent(Event e) {
        System.out.println(e.getTime() + " Arrival Customer "
                + e.getTheCustomer().getInputNumber());
        // Creates a FinishedShopping event for this customer and adds it to the PQ 
        double finishedShoppingTime = e.getTime()
                + (e.getTheCustomer().getOrderSize() * e.getTheCustomer().getTimePerItem());
        finishedShoppingTime = round(finishedShoppingTime);
        e.getTheCustomer().setFinishedShoppingTime(finishedShoppingTime);
        FinishedShoppingEvent fse = new FinishedShoppingEvent(finishedShoppingTime, e.getTheCustomer());
        return fse;
    } // End makeFinishedShoppingEvent method

    // This method takes FinishedShoppingEvents and makes them CheckoutEvents
    public static CheckoutEvent makeCheckoutEvent(Event e) {
        // FinishedShoppingEvent statement
        System.out.println(e.getTime() + " Finished Shopping Customer "
                + e.getTheCustomer().getInputNumber());
        // Picks a checkout lane for this customer
        boolean isAdded = false;
        double checkoutTime;
        int indexOfFL = 0;
        int laneNumber;
        int peopleInLine = 0;
        while (!isAdded) {
            if (e.getTheCustomer().getOrderSize() <= 12) {
                for (int i = 0; i < lanes.size(); i++) {
                    if (lanes.get(i).size() == peopleInLine) {
                        indexOfFL = i;
                        System.out.println("12 items or fewer, chose Lane " + (indexOfFL + 1));
                        isAdded = true;
                        break;
                    }
                }
            } else {
                for (int i = 0; i < lanes.size(); i++) {
                    if (lanes.get(i).size() == peopleInLine) {
                        if (lanes.get(i) instanceof RegularCheckoutLane) {
                            indexOfFL = i;
                            System.out.println("More than 12 items, chose Lane " + (indexOfFL + 1));
                            isAdded = true;
                            break;
                        }
                    }
                }
            }
            peopleInLine++;
        }
        // Adds them to that lane 
        e.getTheCustomer().setPeopleInLine(peopleInLine - 1);
        laneNumber = indexOfFL + 1;
        e.getTheCustomer().setLaneNumber(indexOfFL + 1);
        if (e.getTheCustomer().getOrderSize() <= 12) {
            checkoutTime = e.getTime() + lanes.get(indexOfFL).getWaitTime()
                    + (1 + e.getTheCustomer().getOrderSize() * 0.1);
        } else {
            checkoutTime = e.getTime() + lanes.get(indexOfFL).getWaitTime()
                    + (2 + e.getTheCustomer().getOrderSize() * 0.05);
        }
        checkoutTime = round(checkoutTime);
        e.getTheCustomer().setCheckoutTime(checkoutTime);
        lanes.get(indexOfFL).offer(e.getTheCustomer());
        // Schedules a CheckoutEvent based on how many people are ahead
        // of them in that line, and adds that event to the PQ
        CheckoutEvent ce = new CheckoutEvent(checkoutTime, e.getTheCustomer());
        return ce;
    } // End makeCheckoutEvent method

    public static void checkoutEvent(Event e) {
        double timeWaited;
        double frontOfTheLine;
        if ((e.getTheCustomer().getOrderSize() <= 12)) {
            timeWaited = e.getTheCustomer().getCheckoutTime()
                    - e.getTheCustomer().getFinishedShoppingTime()
                    - (1 + e.getTheCustomer().getOrderSize() * 0.1);
        } else {
            timeWaited = e.getTheCustomer().getCheckoutTime()
                    - e.getTheCustomer().getFinishedShoppingTime()
                    - (2 + e.getTheCustomer().getOrderSize() * 0.05);
        }
        timeWaited = round(timeWaited);
        if ((e.getTheCustomer().getOrderSize() <= 12)) {
            frontOfTheLine = e.getTheCustomer().getCheckoutTime()
                    - (1 + e.getTheCustomer().getOrderSize() * 0.1);
        } else {
            frontOfTheLine = e.getTheCustomer().getCheckoutTime()
                    - (2 + e.getTheCustomer().getOrderSize() * 0.05);
        }
        timeWaited = round(timeWaited);
        frontOfTheLine = round(frontOfTheLine);
        // This is used to calculate the average in ending()
        totalTimeWaited = totalTimeWaited + timeWaited;

        // Checkout statement
        System.out.println(e.getTheCustomer().getCheckoutTime() + " Finished Checkout Customer "
                + e.getTheCustomer().getInputNumber() + " on Lane "
                + e.getTheCustomer().getLaneNumber()
                + "\n(" + timeWaited + " minute wait, "
                + e.getTheCustomer().getPeopleInLine()
                + " people in line -- finished shopping at "
                + e.getTheCustomer().getFinishedShoppingTime()
                + ", got to the front of the line at "
                + frontOfTheLine + ")");

        // Polls the customer from their lane
        for (int i = 0; i < lanes.size(); i++) {
            if (lanes.get(i).contains(e.getTheCustomer())) {
                lanes.get(i).poll();
            }
        }
    } // End checkoutEvent method

    // This method makes the average statements at the end.
    private static void ending() {
        double averageTimeWaited;
        int numExpressLanes = 0;
        int numRegularLanes = 0;
        // Counts the number of each type of lane
        for (int i = 0;
                i < lanes.size();
                i++) {
            if (lanes.get(i) instanceof ExpressCheckoutLane) {
                numExpressLanes++;
            } else {
                numRegularLanes++;
            }
        }
        // Statement for statistics
        System.out.println(
                "The statistics with " + numExpressLanes + " express lanes and "
                + numRegularLanes + " regular lanes is as follows:");
        // More statements...
        averageTimeWaited = totalTimeWaited / customerCount;
        averageTimeWaited = round(averageTimeWaited);
        System.out.println(
                "The average time waited is: " + averageTimeWaited);
    } // End ending method
} // End Project 04
