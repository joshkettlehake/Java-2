/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs1181.project04.kettlehake;

import java.util.LinkedList;
import java.util.Queue;

public class ExpressCheckoutLane extends CheckoutLane {
    private Queue<Customer> q;
    
    // Constructor
    public ExpressCheckoutLane() {
        q = new LinkedList();
    }

    // Abstract method overrides
    @Override
    public double getCheckoutTime() {
        try{
        return 1 + (0.1 * this.peek().getOrderSize());
        }catch(NullPointerException e){        
        }
        return 0;
        }
    
    @Override
    public double getWaitTime() {
        if (this.isEmpty()) {
            return 0.0;
        } else {
            double waitTime = 0;
            for (int i = 0; i < this.size(); i++) {
                waitTime = waitTime + 1 + (0.1 * this.get(i).getOrderSize());
            }
            return waitTime;
        }
    }
}
