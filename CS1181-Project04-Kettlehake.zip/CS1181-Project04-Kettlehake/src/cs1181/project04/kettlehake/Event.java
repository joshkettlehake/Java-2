package cs1181.project04.kettlehake;

public class Event implements Comparable<Event>{
    private double time;
    private Customer theCustomer;

    // Constructor
    public Event(double time, Customer theCustomer) {
        this.time = time;
        this.theCustomer = theCustomer;
    }

    // Getters
    public double getTime() {
        return time;
    }

    public Customer getTheCustomer() {
        return theCustomer;
    }
    
    // Comparable override
    @Override
    public int compareTo(Event o) {
        if(this.time < o.time){
            return -1;
        } else if (this.time > o.time){
            return 1;
        } else {
            return 0;
        }
    }    
}
