package cs1181.project04.kettlehake;

public class Customer {
    private int inputNumber;
    private int laneNumber;
    private int peopleInLine;
    private double checkoutTime;
    private double finishedShoppingTime;
    private double orderSize;
    private double timePerItem;

    // No args constructor
    public Customer() {
    }

    // Multi arg constructor
    public Customer(int inputNumber, int laneNumber, int peopleInLine, double checkoutTime, double finishedShoppingTime, double orderSize, double timePerItem) {
        this.inputNumber = inputNumber;
        this.laneNumber = laneNumber;
        this.peopleInLine = peopleInLine;
        this.checkoutTime = checkoutTime;
        this.finishedShoppingTime = finishedShoppingTime;
        this.orderSize = orderSize;
        this.timePerItem = timePerItem;
    }
 
    // Getters and setters
    public int getInputNumber() {
        return inputNumber;
    }

    public void setInputNumber(int inputNumber) {
        this.inputNumber = inputNumber;
    }

    public int getLaneNumber() {
        return laneNumber;
    }

    public void setLaneNumber(int laneNumber) {
        this.laneNumber = laneNumber;
    }

    public int getPeopleInLine() {
        return peopleInLine;
    }

    public void setPeopleInLine(int peopleInLine) {
        this.peopleInLine = peopleInLine;
    }

    public double getCheckoutTime() {
        return checkoutTime;
    }

    public void setCheckoutTime(double checkoutTime) {
        this.checkoutTime = checkoutTime;
    }

    public double getFinishedShoppingTime() {
        return finishedShoppingTime;
    }

    public void setFinishedShoppingTime(double finishedShoppingTime) {
        this.finishedShoppingTime = finishedShoppingTime;
    }

    public double getOrderSize() {
        return orderSize;
    }

    public void setOrderSize(double orderSize) {
        this.orderSize = orderSize;
    }

    public double getTimePerItem() {
        return timePerItem;
    }

    public void setTimePerItem(double timePerItem) {
        this.timePerItem = timePerItem;
    }
}
