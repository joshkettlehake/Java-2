package cs1181.project04.kettlehake;

public class CheckoutEvent extends Event{
       
    // superConstructor
    public CheckoutEvent(double time, Customer theCustomer) {
        super(time, theCustomer);
    }
}
