package cs1181.project04.kettlehake;

import java.util.LinkedList;
import java.util.Queue;

public class RegularCheckoutLane extends CheckoutLane {

    private Queue<Customer> q;

    // Constructor
    public RegularCheckoutLane() {
        q = new LinkedList();
    }

    // Abstract method overrides
    @Override
    public double getCheckoutTime() {
        try {
            return 2 + (0.05 * this.peek().getOrderSize());
        } catch (NullPointerException e) {
        }
        return 0;
    }

    @Override
    public double getWaitTime() {
        if (this.isEmpty()) {
            return 0.0;
        } else {
            double waitTime = 0;
            for (int i = 0; i < this.size(); i++) {
                waitTime = waitTime + 2 + (0.05 * this.get(i).getOrderSize());
            }
            return waitTime;
        }
    }
}
