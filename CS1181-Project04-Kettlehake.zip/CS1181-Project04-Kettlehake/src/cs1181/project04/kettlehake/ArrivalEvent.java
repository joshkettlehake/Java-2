package cs1181.project04.kettlehake;

public class ArrivalEvent extends Event{
    
    // superConstructor
    public ArrivalEvent(double time, Customer theCustomer) {
        super(time, theCustomer);
    }
}
