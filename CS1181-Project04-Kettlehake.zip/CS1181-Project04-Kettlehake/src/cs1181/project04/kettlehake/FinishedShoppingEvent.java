package cs1181.project04.kettlehake;

public class FinishedShoppingEvent extends Event{
    
    // superConstructor
    public FinishedShoppingEvent(double time, Customer theCustomer) {
        super(time, theCustomer);
    }
}
