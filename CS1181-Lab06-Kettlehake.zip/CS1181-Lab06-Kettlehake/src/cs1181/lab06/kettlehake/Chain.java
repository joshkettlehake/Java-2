package cs1181.lab06.kettlehake;

public class Chain<E> {

    private Link<E> head;
    private int size = 0;

    // Constructor
    public Chain() {
    } // End Chain constructor

    // Self-explanatory
    public void add(E weight) {
        size++;
    } // End add method

    // This method removes the instance of the weight closes to the head pointer of the "LinkedList"
    public boolean remove(E weight) {
        if (head.getWeight() == weight && size > 1) {
            head = head.getNext();
            return true;
        } else {
            Link current = head;
            boolean isDone = false;
            while (isDone == false) {
                if (current.getNext().getWeight() == weight) {
                    current.setNext(current.getNext().getNext());
                    size--;
                    return true;
                } else {
                    current = current.getNext();
                    if (current.getNext() == null) {
                        return false;
                    } // End if statement
                } // End if-else
            } // End while loop
        } // End if-else
        return false;
    } // End remove method

    // This method removes (int)number of targer weights from are "LinkedList" if and only if it is possible to do so
    public boolean removeN(E weight, int number) {
        int count = 0;
        Link current = head;
        // finding the number of instances of target weight
        for (int i = 0; i < size; i++) {
            if (current.getWeight() == weight) {
                count++;
                current = current.getNext();
            } else {
                current = current.getNext();
            } // End if-else
        } // End for loop
        // returns false if doing so is not possible
        if (count < number) {
            return false;
        } else {
            count = 0;
            // Checks to make sure the head is not a target weight
            while (head.getWeight() == weight) {
                head = head.getNext();
                size--;
                count++;
                if (count == number) {
                    return true;
                } // End if statement
            } // End while loop
            current = head;
            // Removes the remaining instances of the target weight not removed as heads in the prior while loop
            for (int i = 0; i < size; i++) {
                if (current.getNext().getWeight() == weight) {
                    current.setNext(current.getNext().getNext());
                    current = current.getNext();
                    size--;
                    count++;
                    if (count == number) {
                        return true;
                    } // End if statement
                } else {
                    current = current.getNext();
                } // End if-else
            } // End for loop
        } // End if-else
        return false;
    } // End removeN method

    // This method removes the instance of the weight furthest to the head pointer of the "LinkedList"
    public boolean removeLast(E weight) {
        int counter = 0;
        int instances = 0;
        Link current = head;
        // Checks to see how many instances of the target weight are in the "LinkedList"
        for (int i = 0; i < size; i++) {
            if (current.getWeight() == weight) {
                instances++;
                current = current.getNext();
            } else {
                current = current.getNext();
            } // End if-else
        } // End for loop
        boolean isDone = false;
        current = head;
        // Iterates through the "LinkedList" finding the last instance of the target weight and removing it
        while (isDone == false) {
            if (current.getNext().getWeight() == weight) {
                counter++;
                if (counter == instances) {
                    current.setNext(current.getNext().getNext());
                    size--;
                    isDone = true;
                } // End if statement
                current = current.getNext();
            } else {
                current = current.getNext();
            } // End if-else
        } // End while loop
        return isDone;
    } // End removeLast method

    // Self-explanatory
    public int getSize() {
        return size;
    }

    @Override
    public String toString() {
        String string = "[";
        Link current = head;
        for (int i = 0; i < size; i++) {
            if (i == (size - 1)) {
                string = string + current.toString();
            } else {
                string = string + current.toString() + ", ";
                current = current.getNext();
            } // End if-else
        } // End for loop
        string = string + "]";
        return string;
    } // End toString override

    // This method sets the initial head pointer of the "LinkedList"
    public void setHead(Link<E> head) {
        this.head = head;
    } // End setHead method
} // End Chain class
