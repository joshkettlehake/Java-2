package cs1181.lab06.kettlehake;

public class CS1181Lab06Kettlehake {

    public static void main(String[] args) {
        Chain<Integer> chain = new Chain();
 
        // Constructing the "LinkedList"
        Link<Integer> a = new Link(3);
        chain.add(a.getWeight());
        // Setting the head pointer
        chain.setHead(a);
        Link<Integer> b = new Link(4);
        chain.add(b.getWeight());
        a.setNext(b);
        Link<Integer> c = new Link(7);
        chain.add(c.getWeight());
        b.setNext(c);
        Link<Integer> d = new Link(6);
        chain.add(d.getWeight());
        c.setNext(d);
        Link<Integer> e = new Link(3);
        chain.add(e.getWeight());
        d.setNext(e);
        Link<Integer> f = new Link(2);
        chain.add(f.getWeight());
        e.setNext(f);
        Link<Integer> g = new Link(9);
        chain.add(g.getWeight());
        f.setNext(g);
        Link<Integer> h = new Link(6);
        chain.add(h.getWeight());
        g.setNext(h);
        Link<Integer> i = new Link(3);
        chain.add(i.getWeight());
        h.setNext(i);
        i.setNext(null);

        // Starter test code
        System.out.println(chain);
        chain.removeN(6, 2);
        System.out.println(chain);
        chain.removeN(3, 2);
        System.out.println(chain);
        System.out.println(chain.removeN(7, 2));
        // My additional tests
        // chain.remove(7);
        // chain.removeLast(6);
        System.out.println(chain);
    } // End main method
} // End Lab06
