package cs1181.lab06.kettlehake;

public class Link <E> extends Chain{
    private E weight;
    private Link next;

    public Link() {
    }

    public Link(E weight) {
        this.weight = weight;
    }

    public Link(E weight, Link next) {
        this.weight = weight;
        this.next = next;
    }
    
    public E getWeight() {
        return weight;
    }

    public Link getNext() {
        return next;
    }

    public void setNext(Link next) {
        this.next = next;
    }

    @Override
    public String toString() {
        return this.getWeight().toString();
    }
}
