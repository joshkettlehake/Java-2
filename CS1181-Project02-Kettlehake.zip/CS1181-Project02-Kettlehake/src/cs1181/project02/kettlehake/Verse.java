package cs1181.project02.kettlehake;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Verse {

    // Class variables
    private Label label;
    private TextField userInput;
    private Label label2;
    private String answer;
    private Label complementNext;
    private ImageView picture;
    private String questionHint;

    // No argument constructor
    public Verse() {
    }

    // Multiple argument constructor
    public Verse(Label label, TextField userInput, Label label2, String answer, Label complementNext, String picture, String questionHint) {
        this.label = label;
        this.userInput = userInput;
        this.label2 = label2;
        this.answer = answer;
        this.picture = new ImageView(new Image(picture, 465, 300, false, false, false));
        this.questionHint = questionHint;
    }

    // Getters and setters
    public Label getLabel() {
        return label;
    }

    public void setLabel(Label label) {
        this.label = label;
    }

    public TextField getUserInput() {
        return userInput;
    }

    public void setUserInput(TextField userInput) {
        this.userInput = userInput;
    }

    public Label getLabel2() {
        return label2;
    }

    public void setLabel2(Label label2) {
        this.label2 = label2;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Label getComplementNext() {
        return complementNext;
    }

    public void setComplementNext(Label complementNext) {
        this.complementNext = complementNext;
    }

    public ImageView getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = new ImageView(new Image(picture, 465, 300, false, false, false));
    }

    public String getQuestionHint() {
        return questionHint;
    }

    public void setQuestionHint(String questionHint) {
        this.questionHint = questionHint;
    }
} // End Verse class
