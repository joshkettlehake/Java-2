package cs1181.project02.kettlehake;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/*
 * Joshua Kettlehae
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
 */
public class CS1181Project02Kettlehake extends Application {

    // These are the global variables I felt it necessary to use for this project.
    private final int INITIAL_WIDTH_IN_PIXELS = 500;
    private final int INITAL_HEIGHT_IN_PIXELS = 425;
    private static Scene scene;
    private static Stage stage;
    private HBox pane1;
    private HBox pane2;
    private HBox pane3;
    private HBox pane4;
    private static final ArrayList<Verse> verses = new ArrayList<>();
    private int currentQuestionNumber;
    private int hintCounter;
    private int skipCounter;
    private static Button nextQuestion;
    private static Button checkAnswer;
    private static Button hint;
    private static Button skip;
    private static Button quit;
    private static VBox root;

    public static void main(String[] args) {
        launch(args);
    } // End main method

    @Override
    public void start(Stage primaryStage) {
        CS1181Project02Kettlehake.stage = primaryStage;
        currentQuestionNumber = 0;
        hintCounter = 0;
        skipCounter = 0;
        introduction();
        createsVersus();

        // initializing (most of) the buttons I will be using
        checkAnswer = new Button("Check Answer");
        checkAnswer.setOnAction(e -> {
            checkAnswer();
        });

        hint = new Button("Hint");
        hint.setOnAction(e -> {
            giveHint();
        });

        skip = new Button("Skip");
        skip.setOnAction(e -> {
            skip();
        });

        quit = new Button("Quit");
        quit.setOnAction(e -> {
            primaryStage.close();
            System.exit(0);
        });
        // Most everything is coming from this method call
        theGame();
    } // End start method

    // This method is the required introduction and explaination to the player
    private void introduction() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Introduction");
        alert.setHeaderText("Welcome to \"In the Beginning\"");
        alert.setContentText("This game will test your knowledge of "
                + "the New King James Bible. Starting at Genesis 1:1"
                + ", you will have a chance to fill in the blank of "
                + "each sentence. Don't worry though. You can use th"
                + "e 'hint' button to help you along the way.");
        alert.showAndWait();
    } // End introduction method

    // This method moves the game along
    private void nextQuestion() {
        currentQuestionNumber++;
        theGame();
    }

    // This method checks the user input against the correct answer for each question
    private void checkAnswer() {
        if (verses.get(currentQuestionNumber).getAnswer().equalsIgnoreCase(verses.get(currentQuestionNumber).getUserInput().getText()) == true) {
            nextQuestion = new Button();
            nextQuestion.setGraphic(verses.get(currentQuestionNumber).getPicture());
            nextQuestion.setOnAction(e -> {
                nextQuestion();
            });
            pane2.getChildren().removeAll(checkAnswer, hint, skip);
            pane3 = new HBox(10);
            pane3.getChildren().add(nextQuestion);
            pane4 = new HBox(10);
            pane4.getChildren().add(verses.get(currentQuestionNumber).getComplementNext());
            root.getChildren().addAll(pane3, pane4);
        } else {
            // This will alert the player if their answer is incorrect
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("");
            alert.setHeaderText("That answer is incorrect.\nPlease try again.");
            alert.setContentText("Remember:\n\nYou can ask for a hint.\n-OR-\nYou can skip the question.");
            alert.showAndWait();
        }
    }

    // Opens an alert giving the player a hint for each of the questions asked
    // This is also part of my score keeping system
    private void giveHint() {
        hintCounter++;
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Hint");
        alert.setHeaderText(verses.get(currentQuestionNumber).getQuestionHint());
        alert.setContentText("For additional help, I'd recommend:\n\nhttps://www.biblegateway.com/");
        alert.showAndWait();
    }

    // This is also part of my score keeping system
    private void skip() {
        currentQuestionNumber++;
        skipCounter++;
        theGame();
    }

    // This method will direct the player to play each part of the game prior to directing them to an end stage
    private void theGame() {
        if (currentQuestionNumber < verses.size()) {
            stage.setScene(makesScene());
        } else {
            stage.setScene(ending());
        }
        stage.show();
    } // End theGame method

    // This method makes all of the scenes besides the ending scene
    private Scene makesScene() {
        root = new VBox(10);
        root.setPadding(new Insets(10, 10, 10, 10));
        scene = new Scene(root, INITIAL_WIDTH_IN_PIXELS, INITAL_HEIGHT_IN_PIXELS);
        stage.setTitle("In the Beginning");
        pane1 = new HBox(10);
        pane1.getChildren().addAll(verses.get(currentQuestionNumber).getLabel(), verses.get(currentQuestionNumber).getUserInput(), verses.get(currentQuestionNumber).getLabel2());
        root.getChildren().add(pane1);
        pane2 = new HBox(10);
        pane2.getChildren().addAll(checkAnswer, hint, skip, quit);
        root.getChildren().add(pane2);
        return scene;
    }

    // This method makes the ending scene with the score counters
    private Scene ending() {
        root = new VBox(10);
        root.setPadding(new Insets(10, 10, 10, 10));
        scene = new Scene(root, INITIAL_WIDTH_IN_PIXELS, INITAL_HEIGHT_IN_PIXELS);
        stage.setTitle("In the Beginning");
        pane1 = new HBox(10);
        Label end1 = new Label("CONGRATULATIONS!");
        pane1.getChildren().add(end1);
        pane2 = new HBox(10);
        Label end2 = new Label("You have made it to the end of the game.");
        pane2.getChildren().add(end2);
        pane3 = new HBox(10);
        Label end3 = new Label("You used " + hintCounter + " hints, and " + skipCounter + " skips.");
        pane3.getChildren().add(end3);
        pane4 = new HBox(10);
        Button endButton = new Button();
        endButton.setGraphic(new ImageView(new Image("file:src/CS1181/project02/kettlehake/CS12.jpg", 465, 315, false, false, false)));
        endButton.setOnAction(e -> {
            System.exit(0);
        });
        pane4.getChildren().add(endButton);
        root.getChildren().addAll(pane1, pane2, pane3, pane4);
        return scene;
        // System.exit(0);
    }

    // This method creates the objects in the array list for the game
    // This could have been done using file I/O, but I chose to leave it this way
    private void createsVersus() {
        Verse verse1 = new Verse();
        verse1.setLabel(new Label("In the beginning"));
        verse1.setUserInput(new TextField());
        verse1.setLabel2(new Label("created the heavens and the earth."));
        verse1.setAnswer("God");
        verse1.setComplementNext(new Label("That's right!   Click the picture to move on to the next verse -->"));
        verse1.setPicture("file:src/CS1181/project02/kettlehake/CS11.jpg");
        verse1.setQuestionHint("God is the creator of all good things.");
        verses.add(verse1);

        Verse verse2a = new Verse();
        verse2a.setLabel(new Label("The earth was without"));
        verse2a.setUserInput(new TextField());
        verse2a.setLabel2(new Label(", and void;"));
        verse2a.setAnswer("form");
        verse2a.setComplementNext(new Label("Correct!   Click the picture to move on to the next verse -->"));
        verse2a.setPicture("file:src/CS1181/project02/kettlehake/CS10.jpg");
        verse2a.setQuestionHint("We use a mold, or a FORM, to cast new objects.");
        verses.add(verse2a);

        Verse verse2b = new Verse();
        verse2b.setLabel(new Label("and"));
        verse2b.setUserInput(new TextField());
        verse2b.setLabel2(new Label("was on the face of the deep."));
        verse2b.setAnswer("darkness");
        verse2b.setComplementNext(new Label("Very good!   Click the picture to move on to the next verse -->"));
        verse2b.setPicture("file:src/CS1181/project02/kettlehake/CS3.jpg");
        verse2b.setQuestionHint("DARKNESS, because there was not yet light.");
        verses.add(verse2b);

        Verse verse2c = new Verse();
        verse2c.setLabel(new Label("And the"));
        verse2c.setUserInput(new TextField());
        verse2c.setLabel2(new Label("of God was hovering over the face of the waters."));
        verse2c.setAnswer("Spirit");
        verse2c.setComplementNext(new Label("Awesome!   Click the picture to move on to the next verse -->"));
        verse2c.setPicture("file:src/CS1181/project02/kettlehake/CS4.jpg");
        verse2c.setQuestionHint("The Godhead consists of:\nGod the Father,\nGod the Son,\nand God the Holy _ _ _ _ _ _.");
        verses.add(verse2c);

        Verse verse3 = new Verse();
        verse3.setLabel(new Label("Then God said, \"Let there be"));
        verse3.setUserInput(new TextField());
        verse3.setLabel2(new Label("\"; and there was light."));
        verse3.setAnswer("light");
        verse3.setComplementNext(new Label("Keep it up!   Click the picture to move on to the next verse -->"));
        verse3.setPicture("file:src/CS1181/project02/kettlehake/CS6.jpg");
        verse3.setQuestionHint("It helps you to see when you are in the darkness.");
        verses.add(verse3);

        Verse verse4a = new Verse();
        verse4a.setLabel(new Label("And God saw the light that it was"));
        verse4a.setUserInput(new TextField());
        verse4a.setLabel2(new Label(";"));
        verse4a.setAnswer("good");
        verse4a.setComplementNext(new Label("That's right!   Click the picture to move on to the next verse -->"));
        verse4a.setPicture("file:src/CS1181/project02/kettlehake/CS5.jpg");
        verse4a.setQuestionHint("Not bad, but _ _ _ _...");
        verses.add(verse4a);

        Verse verse4b = new Verse();
        verse4b.setLabel(new Label("and God"));
        verse4b.setUserInput(new TextField());
        verse4b.setLabel2(new Label("the light from the darkness."));
        verse4b.setAnswer("divided");
        verse4b.setComplementNext(new Label("You're almost there!   Click the picture to move on to the next verse -->"));
        verse4b.setPicture("file:src/CS1181/project02/kettlehake/CS7.jpg");
        verse4b.setQuestionHint("In math, there is:\nAdded,\nSubtracted,\nMultiplied,\nand _ _ _ _ _ _ _...");
        verses.add(verse4b);

        Verse verse5a = new Verse();
        verse5a.setLabel(new Label("God called the light"));
        verse5a.setUserInput(new TextField());
        verse5a.setLabel2(new Label(", and the darkness He called Night."));
        verse5a.setAnswer("Day");
        verse5a.setComplementNext(new Label("One more left!   Click the picture to move on to the next verse -->"));
        verse5a.setPicture("file:src/CS1181/project02/kettlehake/CS9.jpg");
        verse5a.setQuestionHint("He called the darkness night,\nso He called the light _ _ _.");
        verses.add(verse5a);

        Verse verse5b = new Verse();
        verse5b.setLabel(new Label("So the evening and the morning were the"));
        verse5b.setUserInput(new TextField());
        verse5b.setLabel2(new Label("day."));
        verse5b.setAnswer("first");
        verse5b.setComplementNext(new Label("You did it!   Click the picture to see your results -->"));
        verse5b.setPicture("file:src/CS1181/project02/kettlehake/CS8.jpg");
        verse5b.setQuestionHint("_ _ _ _ _, second, third, fourth,\nfifth, sixth, seventh...");
        verses.add(verse5b);
    } // End addVerses method
} // End Project02
