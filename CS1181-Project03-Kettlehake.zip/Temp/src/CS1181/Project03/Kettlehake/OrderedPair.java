/*
 * My OrderedPair class creates ordered pairs with an object and an instance.
 * It has a no arg constructor, a multi-arg constructor, getters, and setters.
 */
package CS1181.Project03.Kettlehake;

public class OrderedPair<T> {
    
    private T t;
    private int instances;

    public OrderedPair() {
    }
    
    public OrderedPair(T t, int instances) {
        this.t = t;
        this.instances = instances;
    }

    public T getT() {
        return t;
    }

    public void setT(T t) {
        this.t = t;
    }

    public int getInstances() {
        return instances;
    }

    public void setInstances(int instances) {
        this.instances = instances;
    }
}
