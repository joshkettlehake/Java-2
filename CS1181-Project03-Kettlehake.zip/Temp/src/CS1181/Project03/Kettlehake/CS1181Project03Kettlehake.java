/*
 * This program does many fancy math things with multisets
 * I have used the OrderedPair class to organize my multisets within arrays
 * My biggest issue was with null Multisets.
 */
package CS1181.Project03.Kettlehake;

/*
 * Joshua Kettlehake
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
 */
public class CS1181Project03Kettlehake {

    static Multiset<Integer> emptyISet = new Multiset<>(); // Will remain empty {}
    static Multiset<Integer> i1 = new Multiset<>();
    static Multiset<Integer> i2 = new Multiset<>();
    static Multiset<Integer> i3 = new Multiset<>();

    static Multiset<String> emptySSet = new Multiset<>(); // Will remain empty {}
    static Multiset<String> s1 = new Multiset<>();
    static Multiset<String> s2 = new Multiset<>();
    static Multiset<String> s3 = new Multiset<>();
    static Multiset<String> s4 = new Multiset<>();

    static Multiset<Integer> nullISet = null;
    static Multiset<String> nullSSet = null;
    static Multiset<String> testSMultiset = new Multiset<>(); // Test set
    static Multiset<Integer> testIMultiset = new Multiset<>(); // Test set

    static OrderedPair cats10 = new OrderedPair("cats", 10);
    static OrderedPair cats20 = new OrderedPair("cats", 20);
    static OrderedPair dogs10 = new OrderedPair("dogs", 10);
    static OrderedPair dogs20 = new OrderedPair("dogs", 20);
    static OrderedPair ones200 = new OrderedPair(1, 200);
    static OrderedPair ones300 = new OrderedPair(1, 300);
    static OrderedPair ones500 = new OrderedPair(1, 500);
    static OrderedPair twos200 = new OrderedPair(2, 200);
    static OrderedPair twos300 = new OrderedPair(2, 300);
    static OrderedPair threes300 = new OrderedPair(3, 300);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        // i1 contains {(1, 500)}
        i1.add(ones500);
        // i2 contains {(1, 300),(2, 200)}
        i2.add(ones300);
        i2.add(twos200);
        // i3 contains {(1, 200),(2, 300),(3, 300)}
        i3.add(ones200);
        i3.add(twos300);
        i3.add(threes300);

        // s1 contains {(cats, 10),(dogs, 10)}
        s1.add(cats10);
        s1.add(dogs10);
        // s2 contains {(cats, 20),(dogs, 20)}
        s2.add(cats20);
        s2.add(dogs20);
        // s3 contains {(cats, 10),(dogs, 20)}
        s3.add(cats10);
        s3.add(dogs20);
        // s4 contains {(cats, 20),(dogs, 10),(ducks, 1)}
        s4.add(cats20);
        s4.add(dogs10);

        // Testing my add(T t) method 
        s4.add("ducks");
        // Testing to see if the same method iterates properly
        s4.add("ducks");

        testUnion();
        testIntersection();
        testDifference();
        testJoin();
        testLength();
        testOccurence();
    }

    private static void testUnion() {
        System.out.println("Union test:");
        System.out.println("The union of the emptyISet and i1 should be {(1, 500)}.");
        testIMultiset = emptyISet.union(i1);
        System.out.println("This union displayed: " + testIMultiset.display());
        System.out.println("The union of i2 and i3 should be {(1, 300),(2, 300),(3, 300)}.");
        testIMultiset = i2.union(i3);
        System.out.println("This union displayed: " + testIMultiset.display());
        System.out.println("The union of s3 and s4 should be {(cats, 20),(dogs, 20),(ducks, 2)}.");
        testSMultiset = s3.union(s4);
        System.out.println("This union displayed: " + testSMultiset.display());
        System.out.println("The union of the nullSSet and s1 should be {(cats, 10),(dogs, 10)}.");
        try {
            testSMultiset = nullSSet.union(s1);
            System.out.println("This union displayed: " + testSMultiset.display());
        } catch (NullPointerException e) {
        } finally {
            System.out.println("This union cannot be displayed due to a NullPointerException (which I have caught).");
        }
    }

    private static void testIntersection() {
        System.out.println("\nIntersection test:");
        System.out.println("The intersection of i2 and i3 should be {(1, 200),(2, 200)}");
        testIMultiset = i2.intersection(i3);
        System.out.println("This intersection displayed: " + testIMultiset.display());
        System.out.println("The intersection of emptySSet and s1 shoud be {}");
        testSMultiset = emptySSet.intersection(s1);
        System.out.println("This intersection displayed: " + testSMultiset.display());
        System.out.println("The intersection of nullISet and i1 should be {}");
        try {
            testIMultiset = nullISet.intersection(i1);
            System.out.println("This intersection displayed: " + testIMultiset.display());
        } catch (NullPointerException e) {
        } finally {
            System.out.println("This intersection cannot be displayed due to a NullPointerException (which I have caught).");
        }
    }

    private static void testDifference() {
        System.out.println("\nDifference test:");
        System.out.println("The differece between the emptyISet and i1 should be {}.");
        testIMultiset = emptyISet.difference(i1);
        System.out.println("This difference displayed: " + testIMultiset.display());
        System.out.println("The difference between i3 and i2 should be {(1, -100)(2, 100)(3, 300)}");
        System.out.println("The rules of this assignment are unclear as to if we are to let instances be negative or if we are to stop them at 0.");
        testIMultiset = i3.difference(i2);
        System.out.println("This difference displeyed: " + testIMultiset.display());
        System.out.println("Differencing cats and dogs and ducks seems like animal cruelty.\n"
                + "I already felt terrible for intersecting them. But, trust me... it works.");
        System.out.println("The difference of nullISet and i1 should be {?}.");
        System.out.println("You can't subtract anything from nothing.");
        System.out.println("But, we'll give it a try!");
        try {
            testIMultiset = nullISet.difference(i1);
            System.out.println("This difference displayed: " + testIMultiset.display());
        } catch (NullPointerException e) {
        } finally {
            System.out.println("Yep... This difference cannot be displayed due to a NullPointerException (which I have caught).");
        }
    }

    private static void testJoin() {
        System.out.println("\nJoin test:");
        System.out.println("We can join cats and dogs and ducks all day!!!");
        System.out.println("s2 joined with s4 is like a million (40) cats and a million (30) dogs and two (2) ducks.");
        testSMultiset = s2.join(s4);
        System.out.println("These joined displays: " + testSMultiset.display());
        System.out.println("Joining emptyISet and i1 should be {(1, 500)},\n"
                + "and i2 joined with i3 should be {(1, 500),(2, 500),(3, 300)}.");
        testIMultiset = emptyISet.join(i1);
        System.out.println("The first displayed is: " + testIMultiset.display());
        testIMultiset = i2.join(i3);
        System.out.println("And, the second is: " + testIMultiset.display());
        System.out.println("We might as well NullPointer this thing again.");
        System.out.println("I've tried many things to prevent this, but I'm just running out of time... tick, tock.");
        try {
            testIMultiset = nullISet.join(i1);
            System.out.println("These joined displays: " + testIMultiset.display());
        } catch (NullPointerException e) {
            System.out.println("Nope!");
        }
    }

    private static void testLength() {
        System.out.println("\nLength test:");
        System.out.println("Set i1 is an empty set,\n"
                + "and I have hard-coded a total of 500 instances into set i1,\n"
                + "500 instances into set i2, and 800 instances into set i3.");
        System.out.println("When I ask for emptyISet.length() the output is: " + emptyISet.length());
        System.out.println("When I ask for i1.length() the output is: " + i1.length());
        System.out.println("When I ask for i2.length() the output is: " + i2.length());
        System.out.println("When I ask for i3.length() the output is: " + i3.length());
        System.out.println("Asking for s4.length() should yield 32 animals.");
        System.out.println("s4.length(): " + s4.length());
        System.out.println("Asking for nullSSet.length() causes a NullPointerException, which I have caught.");
        try {
            System.out.println(nullSSet.length());
        } catch (NullPointerException e) {
        }
    }

    private static void testOccurence() {
        System.out.println("\nOccurence tests:");
        System.out.println("I have hard-coded 500 instances of the number 1 into multiset i1.");
        System.out.println("When I ask for emptyISet.occurence(1) the output is: " + emptyISet.occurence(1));
        System.out.println("When I ask for i1.occurence(1) the output is: " + i1.occurence(1));
        System.out.println("Asking for s3.occurence(\"dogs\") should yield 20 dogs.");
        System.out.println("s3.occurence(\"dogs\"): " + s3.occurence("dogs"));
        System.out.println("Asking for nullISet.occurence(1) causes a NullPointerException, which I have caught.");
        try {
            System.out.println(nullISet.occurence(1));
        } catch (NullPointerException e) {
        }
    }
}
