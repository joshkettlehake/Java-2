/*
 * This is where all of my constructor, math functions, and other things are located.
 */
package CS1181.Project03.Kettlehake;

public class Multiset<T> {

    private OrderedPair[] objArray;

    // no arg constuctor
    public Multiset() {
        objArray = new OrderedPair[10];
    } // End no arg constructor

    // single arg constructor
    public Multiset(T t) {
        objArray = new OrderedPair[10];

        // Checks to see if t is an OrderedPair
        if (t instanceof OrderedPair) {
            this.add(t);
        } else {
            // Makes t the first instance of its own OrderedPair 
            objArray[0] = new OrderedPair(t, 1);
        } // End if-else
    } // End single arg constructor

    // This union of a multiset is a new multiset composed of all of the elements in both
    // multisets with a count of each item equal to the maximum count of the item in either multiset
    public Multiset<T> union(Multiset<T> multiset) {
        Multiset nms = new Multiset();

        // Adds OrderedPair(s) that are in both of the Multiset(s) to the new multiset,
        // and decides which of them has a larger instances
        for (int i = 0; i < this.arrayLength(); i++) {
            boolean didIt = false;
            for (int j = 0; j < multiset.arrayLength(); j++) {
                if ((objArray[i]).getT().equals((multiset.getObjArray()[j]).getT())) {
                    OrderedPair op = new OrderedPair();
                    op.setT((objArray[i]).getT());
                    if ((objArray[i]).getInstances() > (multiset.getObjArray()[j]).getInstances()) {
                        op.setInstances((objArray[i]).getInstances());
                    } else {
                        op.setInstances((multiset.getObjArray()[j]).getInstances());
                    } // End if-else
                    nms.add(op);
                    didIt = true;
                } // End if statement
            } // End j for loop
            // Adds OrderedPair(s) that are exclusive to objArray to new multiset
            if (!didIt) {
                nms.add(objArray[i]);
            } // End if statement
        } // End i for loop
        // Adds OrderedPair(s) that are multiset to objArray to new multiset
        for (int i = 0; i < multiset.arrayLength(); i++) {
            int counter = 0;
            for (int j = 0; j < nms.arrayLength(); j++) {
                if (!((multiset.getObjArray()[i]).getT()).equals((nms.getObjArray()[j]).getT())) {
                    counter++;
                } // End if statement
            } // end j for loop
            if (counter == nms.arrayLength()) {
                nms.add((multiset.getObjArray()[i]));
            } // End if statement
        } // End i for loop
        return nms;
    } // End union method

    // The intersection of two multisets is a new multiset composed of only those elements that appear in both
    // multisets with a count of each item set equal to the minimum count of the item in either multiset
    public Multiset<T> intersection(Multiset<T> multiset) {
        Multiset nms = new Multiset();

        // Adds OrderedPair(s) that are in both of the Multiset(s) to the new multiset,
        // and decides which of them has a smaller instances
        for (int i = 0; i < this.arrayLength(); i++) {
            for (int j = 0; j < multiset.arrayLength(); j++) {
                if ((objArray[i]).getT().equals((multiset.getObjArray()[j]).getT())) {
                    OrderedPair op = new OrderedPair();
                    op.setT((objArray[i]).getT());
                    if ((objArray[i]).getInstances() < (multiset.getObjArray()[j]).getInstances()) {
                        op.setInstances((objArray[i]).getInstances());
                    } else {
                        op.setInstances((multiset.getObjArray()[j]).getInstances());
                    } // End if-else
                    nms.add(op);
                } // End if statement
            } // End j for loop
        } // End i for loop
        return nms;
    } // End intersection method

    // The difference of two multisets is a new multiset composed of only those elements that appear
    // in the first multiset with the count reduced by the count of the same items in the second multiset
    public Multiset<T> difference(Multiset<T> multiset) {
        Multiset nms = new Multiset();

        for (int i = 0; i < this.arrayLength(); i++) {
            boolean didIt = false;
            // Adjusts the instance of the OrderedPair(s) of this multiset that appear in multiset,
            // and adds them to new multiset
            for (int j = 0; j < multiset.arrayLength(); j++) {
                if ((objArray[i]).getT().equals((multiset.getObjArray()[j]).getT())) {
                    OrderedPair op = new OrderedPair();
                    op.setT((objArray[i]).getT());
                    int difference = ((objArray[i]).getInstances()) - ((multiset.getObjArray()[j]).getInstances());
                    op.setInstances(difference);
                    nms.add(op);
                    didIt = true;
                } // End if statement
            } // End j for loop
            // adds the OrderedPair(s) of this multiset that did not need adjusted to new multiset
            if (!didIt) {
                nms.add(objArray[i]);
            } // End if statement
        } // End i for loop
        return nms;
    } // End difference method

    // The join of two multisets is a new multiset composed of all of the elements in both multisets
    // with a count of each item set equal to the sum of the count of the items in both multisets
    public Multiset<T> join(Multiset<T> multiset) {
        Multiset nms = new Multiset();

        // Adjusts the instance of the OrderedPair(s) of this multiset that appear in multiset,
        // and adds them to new multiset
        for (int i = 0; i < this.arrayLength(); i++) {
            boolean didIt = false;
            for (int j = 0; j < multiset.arrayLength(); j++) {
                if ((objArray[i]).getT().equals((multiset.getObjArray()[j]).getT())) {
                    OrderedPair op = new OrderedPair();
                    op.setT(((OrderedPair) objArray[i]).getT());
                    int sum = ((objArray[i]).getInstances()) + ((multiset.getObjArray()[j]).getInstances());
                    op.setInstances(sum);
                    nms.add(op);
                    didIt = true;
                } // End if statement
            } // End j for loop
            // adds the OrderedPair(s) of this multiset that did not need adjusted to new multiset
            if (!didIt) {
                nms.add(objArray[i]);
            } // End if statement
        } // End i for loop
        // adds the OrderedPair(s) of multiset that did not need adjusted to new multiset
        for (int i = 0; i < multiset.arrayLength(); i++) {
            int counter = 0;
            for (int j = 0; j < nms.arrayLength(); j++) {
                if (!((multiset.getObjArray()[i]).getT()).equals((nms.getObjArray()[j]).getT())) {
                    counter++;
                } // End if statement
            } // End j for loop
            if (counter == nms.arrayLength()) {
                nms.add((multiset.getObjArray()[i]));
            } // End if statement
        } // End i for loop
        return nms;
    } // End join method

    // The length of a multiset is the total numbet of items in the multiset
    public int length() {
        int length = 0;
        // Iterates through objArray and adds instances of one to the next and so on
        for (int i = 0; i < this.arrayLength(); i++) {
            length = length + ((objArray[i]).getInstances());
        } // End for loop
        return length;
    } // End length method

    // The occurence of an item is the mumber of times the item appears in the multiset
    public int occurence(T t) {
        int occurences = 0;

        // Iterates through objArray looking for t, and adds its instances to occurences
        for (int i = 0; i < this.arrayLength(); i++) {
            if ((objArray[i]).getT().equals(t)) {
                // I did it this way in case some jerk wanted to hardCode  
                // multiple OrderedPair(s) of the same type (T)...
                occurences = occurences + (objArray[i]).getInstances();
            } // End if statement
        } // End for loop
        return occurences;
    } // End occurence method

    // Displays ordered pairs as (T, instances) within sets {} 
    public String display() {
        String string = "{";

        for (int i = 0; i < this.arrayLength(); i++) {
            string = string + "(" + (objArray[i]).getT() + ", "
                    + (objArray[i]).getInstances() + ")";
            if (i != this.arrayLength() - 1) {
                string = string + ",";
            } // End if statement
        } // End for loop
        string = string + "}";
        return string;
    } // End display method

    // Adds single t(s) to this multiset 
    public Multiset<T> add(T t) {
        boolean isAdded = false;
        for (int i = 0; i < this.arrayLength(); i++) {
            if (objArray[i].getT().equals(t)) {
                objArray[i].setInstances(objArray[i].getInstances() + 1);
                isAdded = true;
            } // End if statement
        } // End for loop
        if (!isAdded) {
            OrderedPair op = new OrderedPair();
            op.setT(t);
            op.setInstances(1);
            this.add(op);
        } // End if statement
        return this;
    } // End add(T t) method

    // Adds OrderedPair(s) to this multiset
    public Multiset<T> add(OrderedPair op) {
        objArray[this.arrayLength()] = op;
        return this;
    } // End add(OrderedPair op) method

    // This is my array.length() method
    public int arrayLength() {
        int notNull = 0;
        for (int i = 0; i < objArray.length; i++) {
            if (objArray[i] != null) {
                notNull++;
            } // End if statement
        } // End for loop
        return notNull;
    } // End my array.length() method

    // This lets me to snipe objArray from other multiset(s)
    public OrderedPair[] getObjArray() {
        return objArray;
    } // End getObjArray method
} // End Multiset class
