/*
 * This program made my head hurt and my eyes cross...
 * It creates an array with 1000 indicies, sorts it,
 * and lets the user search for stuff in it.
 */
package cs1181.lab10.kettlehake;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

/*
 * Joshua Kettlehae
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
 */
public class CS1181Lab10Kettlehake {

    public static void main(String[] args) {
        double[] arr = null;
        arr = part01(arr);
        // You can comment out the displayToConsole method call within part01
        // if you would like to be able to see part02 more clearly
        // The boolean/while loop combo keeps the program running until the user enters -1
        boolean isDone = false;
        while (!isDone) {
            part02(arr);
        }
    }

    private static double[] part01(double[] arr) {
        // Declare an array of double precision data
        arr = new double[1000];
        // Filling the array wih random numbers
        // Citing stackOverflow for random number generator
        double min = 0.0;
        double max = 1000.0;
        double random;
        double inBetween;
        for (int i = 0; i < arr.length; i++) {
            random = new Random().nextDouble();
            inBetween = min + (random * (max - min));
            inBetween = round(inBetween);
            arr[i] = inBetween;
        }
        // Sorting the array in natural order
        // Citing Cheatham's lecture videos        
        quickSort(arr, 0, arr.length - 1);
        // Display the sorted data set on the console
        // Comment this out to see part02 more clearly
        displayToConsole(arr);
        return arr;
    }

    // This method rounds doubles to the nearest three decimal places.
    public static double round(double d) {
        return Math.round(d * 100.0) / 1000.0;
    } // End round method

    // This is a recursive sorting method modified from Cheathams lectures
    private static void quickSort(double[] arr, int start, int end) {
        if (start >= end) {
            return;
        } else {
            // Partition the arr from start to end.
            int pivotIndex = partition(arr, start, end);
            // Call quickSort on the part of the array to the left of the pivot.
            quickSort(arr, start, pivotIndex - 1);
            // Call quickSort on the part of the array to the right of the pivot.
            quickSort(arr, pivotIndex + 1, end);
        }
    } // End quickSort method

    private static int partition(double[] arr, int start, int end) {
        int pivotIndex = (start + end) / 2;
        double pivot = arr[pivotIndex];
        // Notes: step 1
        double temp = arr[start];
        arr[start] = pivot;
        arr[pivotIndex] = temp;
        // Notes: step 2
        int low = start + 1;
        int high = end;
        // Notes: step 6
        while (low < high) {
            // Notes: step 3
            while (low <= end && arr[low] <= pivot) {
                low++;
            }
            // Notes: step 4
            while (high >= 0 && arr[high] >= pivot) {
                high--;
            }
            // Notes: step 5
            if (low < high) {
                temp = arr[low];
                arr[low] = arr[high];
                arr[high] = temp;
            }
        }
        if (high >= 0 && arr[high] < pivot) {
            temp = arr[high];
            arr[high] = pivot;
            arr[start] = temp;
            pivotIndex = high;
        }
        return pivotIndex;
    } // End partition method

    // Self-explainatory
    private static void displayToConsole(double[] arr) {
        System.out.println("The Sorted Array:");
        System.out.print("[");
        for (int i = 0; i < arr.length - 1; i++) {
            System.out.print(arr[i] + ", ");
            // The 50 can be changed to make more of less rows of output...
            if (i > 0 && i % 50 == 0) {
                System.out.print("\n");
            }
        }
        System.out.println(arr[arr.length - 1] + "]");
    } // End displayToConsole method

    private static void part02(double[] arr) {
        Scanner userInput = new Scanner(System.in);
        int input = getUserInput(userInput);
        // Directs course of action based off of userInput
        if (input == 1) {
            one(arr, userInput);
        } else if (input == 0) {
            zero(arr, userInput);
        } else { // if input == -1
            System.exit(0);
        }
    } // End part02 method

    // This method gets the initial user input for course of action
    private static int getUserInput(Scanner userInput) {
        boolean moveOn = false;
        while (!moveOn) {
            // Try-catch does not allow for anything outside of an int between -1 and 1
            try {
                System.out.print("\nEnter type of search (1 = success, 0 = fail, -1 = quit: ");
                int input = userInput.nextInt();
                if (input >= -1 && input <= 1) {
                    userInput.nextLine();
                    return input;
                } else {
                    userInput.nextLine();
                    System.out.println("Follow the instructions better ya dope...");
                }
            } catch (InputMismatchException e) {
                userInput.nextLine();
                System.out.println("Follow the instructions better ya dope...");
            }
        }
        // Unreachable code
        return 0;
    }

    // This method handles a userInput of 1
    private static void one(double[] arr, Scanner userInput) {
        int index = getIndex(userInput);
        double searchValue = arr[index];
        System.out.println("Searching for value DATA[" + index + "] = " + searchValue);
        boolean trueOrFalse = interpolationSearch(arr, searchValue);
        System.out.println("Search returns " + trueOrFalse);
    } // End one method

    // This method handles a userInput of 0
    private static void zero(double[] arr, Scanner userInput) {
        int index = getIndex(userInput);
        double searchValue;
        if (index < 999) {
            searchValue = (arr[index] + arr[index + 1]) / 2;
            System.out.println("Searching for value (DATA[" + index + "] "
                    + "+ DATA[" + (index + 1) + "]) / 2  = " + searchValue);
        } else { // Handles a userInput of 999. 
            searchValue = arr[index] + 1;
            System.out.println("Searching for value DATA[" + index + "] "
                    + "+ 1 = " + searchValue);
        }
        boolean trueOrFalse = interpolationSearch(arr, searchValue);
        System.out.println("Search returns " + trueOrFalse);
    } // End zero method

    // This method gets the userInput index to be searched for
    private static int getIndex(Scanner userInput) {
        boolean moveOn = false;
        while (!moveOn) {
            // Try-catch does not allow for anything outside of an int between 0 and 999
            try {
                System.out.print("Enter index (0...999): ");
                int input = userInput.nextInt();
                if (input >= 0 && input <= 999) {
                    return input;
                } else {
                    userInput.nextLine();
                    System.out.println("Follow the instructions better ya dope...");
                }
            } catch (InputMismatchException e) {
                userInput.nextLine();
                System.out.println("Follow the instructions better ya dope...");
            }
        }
        // Unreachable code
        return 0;
    } // End getIndex method

    private static boolean interpolationSearch(double[] arr, double searchValue) {
        int interpolationIndex;
        int interpolationsCalculated = 0;
        int low = 0;
        int high = arr.length - 1;
        // I tried to do this by recurssion, but could not figure it out...
        // So, you get a while loop containing the interpolationIndex method 
        // call and many checks as to what to do next pieced together from a 
        // few different sources.
        while (low <= high && searchValue >= arr[low] && searchValue <= arr[high]) {
            interpolationIndex = getInterpolationIndex(arr, searchValue, low, high);
            interpolationsCalculated++;
            // checks if our lowIndex matches
            if (low == high) {
                if (arr[low] == searchValue) {
                    interpolationsStatement(interpolationsCalculated);
                    return true;
                } else {
                    interpolationsStatement(interpolationsCalculated);
                    return false;
                }
            }
            // if we found our match
            if (arr[interpolationIndex] == searchValue) {
                interpolationsStatement(interpolationsCalculated);
                return true;
            }
            // Sets new low or high pointers
            if (arr[interpolationIndex] < searchValue) {
                low = interpolationIndex + 1;
            } else {
                high = interpolationIndex - 1;
            }
        }
        // If our pointers have met and still found no match
        interpolationsStatement(interpolationsCalculated);
        return false;
    } // End interpolationSearch method

    // This method gives to us the interpolationIndex to be used
    // It is the formula from the Lab10 instructions (modified)
    private static int getInterpolationIndex(double[] arr, double searchValue, int low, int high) {
        int indexLowerBound = low;
        int indexUpperBound = high;
        double dataLowerBound = arr[indexLowerBound];
        double dataUpperBound = arr[indexUpperBound];

        double dataRange = dataUpperBound - dataLowerBound;
        double percentageDataRange = (searchValue - dataLowerBound) / dataRange;
        int interpolationIndexOffset = (int) (percentageDataRange * (indexUpperBound - indexLowerBound));
        int interpolationIndex = indexLowerBound + interpolationIndexOffset;
        return interpolationIndex;
    } // End getInterpolationIndex method

    // This just seemed like cleaner coding practice...
    private static void interpolationsStatement(int interpolationsCalculated) {
        System.out.println("- Interpolations caculated: " + interpolationsCalculated);
    } // I want pizza...
} // End Lab10
