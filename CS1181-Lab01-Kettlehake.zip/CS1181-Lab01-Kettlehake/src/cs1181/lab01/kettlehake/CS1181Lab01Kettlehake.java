/*
 * This class demonstrates the implementation of the CS1181Set class
 */
package cs1181.lab01.kettlehake;

/*
 * Joshua Kettlehae
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
 */
public class CS1181Lab01Kettlehake {

    public static void main(String[] args) {
        // Sample code
        CS1181Set setA = new CS1181Set(1, 2, 3, 4, 5);
        System.out.println(setA);

        CS1181Set setB = new CS1181Set(2, 5, 7);
        System.out.println(setB);

        CS1181Set setC = new CS1181Set(setA);
        setC.intersection(setB);
        System.out.println("intersection: " + setC);

        setC = new CS1181Set(setA);
        setC.union(setB);
        System.out.println("union: " + setC);

        setC = new CS1181Set(setA);
        setC.difference(setB);
        System.out.println("difference: " + setC);
    } // End main method
} // End lab 01
