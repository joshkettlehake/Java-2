/*
 * In this program we had to modify our main method and the OrderQueue class to
 * ensure that our threads ran smoothly.
 */
package cs1181lab11;

public class CS1181Lab11Kettlehake {

/*
 * Joshua Kettlehae
 * Lab Section: 07
 * Lab Instructor: // NEED A NAME!!!
 * Lecure Instructor: Dr. Cheatham
 */
    public static void main(String[] args) throws InterruptedException {

        OrderQueue orders = new OrderQueue();

        Thread tm = new Thread(new TaskMaster(orders));
        Thread w1 = new Thread(new Worker(orders, 1));
        Thread w2 = new Thread(new Worker(orders, 2));
        Thread w3 = new Thread(new Worker(orders, 3));

        tm.start();
        w1.start();
        w2.start();
        w3.start();
        // Makes sure Finished? does not happen before everything else is done         
        w1.join();
        w2.join();
        w3.join();
        // At first, I didn't realize that we had to join the taskMaster...
        tm.join();

        System.out.println("Finished?");
    }
}
