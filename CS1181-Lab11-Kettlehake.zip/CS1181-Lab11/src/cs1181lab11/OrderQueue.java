package cs1181lab11;

import java.util.ArrayDeque;
import java.util.Queue;
import java.util.logging.Level;
import java.util.logging.Logger;

class OrderQueue {

    private Queue<Task> orders;
    private boolean moreOrdersComing;

    public OrderQueue() {
        orders = new ArrayDeque<>();
        moreOrdersComing = true;
    }

    // Synchronized the method,
    // used a while loop with wait/notifyAll to ensure that no more than 5 
    // tasks are in the queue at any given time.
    public synchronized void createTask(String label, int timeToComplete) {
        while (orders.size() >= 5) {
            try {
                wait();
            } catch (InterruptedException ex) {
                Logger.getLogger(OrderQueue.class.getName()).log(Level.SEVERE, null, ex);
            }
        } 
            notifyAll();
            orders.offer(new Task(label, timeToComplete));
    }

    // Synchronized the method, and used wait/notifyAll to tell the workers what
    // to do when there are no current tasks.
    public synchronized Task acceptTask() {
        while (orders.isEmpty()) {
            try {
                wait();
            } catch (InterruptedException ex) {
            }
        }
        notifyAll();
        return orders.poll();
    }

    public void setNoMoreOrders() {
        moreOrdersComing = false;
    }

    public boolean weAreDone() {
        return orders.isEmpty() && !moreOrdersComing;
    }
}
