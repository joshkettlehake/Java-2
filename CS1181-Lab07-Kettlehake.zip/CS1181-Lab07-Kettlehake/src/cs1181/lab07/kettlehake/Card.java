package cs1181.lab07.kettlehake;

public class Card {

    private String value;
    private String suit;

    public Card(int value, String suit) {

        if (value == 1) {
            this.value = "Ace";
        } else if (value < 11) {
            this.value = String.valueOf(value);
        } else if (value == 11) {
            this.value = "Jack";
        } else if (value == 12) {
            this.value = "Queen";
        } else {
            this.value = "King";
        }

        this.suit = suit;
    }

    @Override
    public String toString() {
        return value + " of " + suit;
    }

    public String getValue() {
        return value;
    }
}
