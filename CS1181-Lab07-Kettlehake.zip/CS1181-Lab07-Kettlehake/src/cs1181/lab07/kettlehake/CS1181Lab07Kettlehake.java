package cs1181.lab07.kettlehake;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Collections;
import java.util.Deque;
import java.util.InputMismatchException;
import java.util.Queue;
import java.util.Scanner;

public class CS1181Lab07Kettlehake {

    static boolean gameOver;
    static int numberOfPlayers;
    static int playerTurn;
    static ArrayList<Player> players = new ArrayList(6);

    public static void main(String[] args) {
        gameOver = false;
        playerTurn = 0;
        getNumberOfPlayers();

        // create the deck of cards
        Queue<Card> deck = new LinkedList<>();
        for (int i = 1; i <= 13; i++) {
            deck.offer(new Card(i, "Hearts"));
            deck.offer(new Card(i, "Diamonds"));
            deck.offer(new Card(i, "Clubs"));
            deck.offer(new Card(i, "Spades"));
        } // End for loop

        // shuffle the deck
        Collections.shuffle((LinkedList) deck);

        // create the players (TODO for extra credit, modify this to 
        // prompt the user for a number between two and six, and support 
        // that many players. Hint: an array or other data structure can 
        // be helpful here)
        Player player1 = new Player("Player 1");
        Player player2 = new Player("Player 2");
        Player player3 = new Player("Player 3");
        Player player4 = new Player("Player 4");
        Player player5 = new Player("Player 5");
        Player player6 = new Player("Player 6");
        players.add(player1);
        players.add(player2);
        players.add(player3);
        players.add(player4);
        players.add(player5);
        players.add(player6);

        // deal five cards to each player
        // The correct way to deal...
        System.out.println("Started dealing");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < numberOfPlayers; j++) {
                players.get(j).addCard(deck.poll());
            } // End j for loop
        } // End i for loop
        System.out.println("Finished dealing");

        // put the remaining cards from the deck into the draw pile (a queue)
        Queue<Card> drawPile = new LinkedList<>();
        while (deck.peek() != null) {
            drawPile.offer(deck.poll());
        } // End while loop

        // create a discard pile (a stack/dequeue) that is initially empty
        Deque<Card> discardPile = new LinkedList<>();
        // simulate the game 

        while (gameOver == false) {
            turn(drawPile, discardPile);
        } // End while loop
        // display who won
        System.out.print("\n" + players.get(playerTurn % numberOfPlayers).getName() + " has won the game!!!");
    } // End main method

    private static void getNumberOfPlayers() {
        Scanner userInput = new Scanner(System.in);
        boolean isDone = false;
        System.out.print("Enter the number of players.\n"
                + "This must be an integer between 2 and 6.\n"
                + "---------------------------------------> ");

        // Forcing an integer between 2 and 6
        while (!isDone) {
            try {
                numberOfPlayers = userInput.nextInt();
                if (numberOfPlayers < 2 || numberOfPlayers > 6) {
                    System.err.println("\nYou must enter an integer between 2 and 6 to continue.");
                    System.out.print("-------------------------------------------------------> ");
                } else {
                    isDone = true;
                } // End if-else statement
            } catch (InputMismatchException e) {
                System.err.println("\nYou must enter an integer between 2 and 6 to continue.");
                System.out.print("-------------------------------------------------------> ");
                userInput.next();
            } // End try-catch
        } // End while loop
    } // End getNumberOfPlayers method

    private static void turn(Queue drawPile, Deque discardPile) {
        discardPile.push(players.get(playerTurn % numberOfPlayers).chooseCard());
        System.out.println("\n" + players.get(playerTurn % numberOfPlayers).getName() + " discarded the " + discardPile.peek().toString() + ".");

        // Checks to see if the currentPlayer is out of cards
        if (players.get(playerTurn % numberOfPlayers).hasMoreCards() == false) {
            gameOver = true;
            return;
        } // End if statement

        // Checks to see if the drawPile is empty
        // If it is, the discardPile is put in the drawPile and shuffeled
        if (drawPile.isEmpty()) {
            while (discardPile.peek() != null) {
                drawPile.offer(discardPile.pop());
            } // End while loop
            Collections.shuffle((LinkedList) drawPile);
        } // End if statement
        
        if (((Card) discardPile.peek()).getValue().equalsIgnoreCase("2")) {
            playerTurn++;
            System.out.println("\n" + players.get(playerTurn % numberOfPlayers).getName() + " drew the " + drawPile.peek().toString());
            players.get(playerTurn % numberOfPlayers).addCard((Card) drawPile.poll());
            System.out.println("and the " + drawPile.peek().toString() + ".");
            players.get(playerTurn % numberOfPlayers).addCard((Card) drawPile.poll());
            playerTurn++;
            // End if "2" gamePlay
        } else if (((Card) discardPile.peek()).getValue().equalsIgnoreCase("8")) {
            System.out.println("\n" + players.get(playerTurn % numberOfPlayers).getName() + " drew the " + drawPile.peek().toString());
            players.get(playerTurn % numberOfPlayers).addCard((Card) drawPile.poll());
            System.out.println("and the " + drawPile.peek().toString() + ".");
            players.get(playerTurn % numberOfPlayers).addCard((Card) drawPile.poll());
            playerTurn++;
            // End if "8" gamePlay
        } else if (((Card) discardPile.peek()).getValue().equalsIgnoreCase("jack")
                || ((Card) discardPile.peek()).getValue().equalsIgnoreCase("queen")
                || ((Card) discardPile.peek()).getValue().equalsIgnoreCase("king")) {
            System.out.println("\n" + players.get(playerTurn % numberOfPlayers).getName() + " takes another turn.");
        } // End jack, queen, or king gamePlay 
        else {
            playerTurn++;
        } // End all other values gamePlay
    } // End turn methor
} // End Lab07
