package cs1181.lab07.kettlehake;

import java.util.ArrayList;
import java.util.Random;

public class Player {

    private String name;
    private ArrayList<Card> cards;

    public Player(String name) {
        this.name = name;
        cards = new ArrayList<>();
    }

    public void addCard(Card card) {
        cards.add(card);
    }

    public boolean hasMoreCards() {
        return cards.size() > 0;
    }

    public String getName() {
        return name;
    }

    // randomly chooses a card to play
    public Card chooseCard() {
        Random rng = new Random();
        int choice = rng.nextInt(cards.size());
        return cards.remove(choice);
    }

    @Override
    public String toString() {
        String result = name + ": ";
        for (Card c : cards) {
            result += c + " ";
        }
        return result;
    }

}
